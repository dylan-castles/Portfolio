// pueblos.js
const pueblos = [
  {
    "pueblo": "Badalona (ur2, ur3, op)",
    "nave": "5",
    "sección": "A",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Centelles",
    "nave": "5",
    "sección": "A",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Tona",
    "nave": "5",
    "sección": "A",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Taradell",
    "nave": "5",
    "sección": "A",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Prat lluçanes",
    "nave": "5",
    "sección": "A",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Navarcles",
    "nave": "5",
    "sección": "A",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Balsareny",
    "nave": "5",
    "sección": "A",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vilanova i la Geltrú",
    "nave": "5",
    "sección": "A",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Esparreguera",
    "nave": "5",
    "sección": "A",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Abrera",
    "nave": "5",
    "sección": "A",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Esteve Sesrovires",
    "nave": "5",
    "sección": "A",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sant Quirze de Besora",
    "nave": "5",
    "sección": "A",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Torello",
    "nave": "5",
    "sección": "A",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Manlleu",
    "nave": "5",
    "sección": "A",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Coloma (use)",
    "nave": "5",
    "sección": "A",
    "posición": "10",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Sta Perpetua",
    "nave": "5",
    "sección": "B",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "La Llagosta",
    "nave": "5",
    "sección": "B",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Polinya",
    "nave": "5",
    "sección": "B",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sentmenat",
    "nave": "5",
    "sección": "B",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Roquetes",
    "nave": "5",
    "sección": "B",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sitges",
    "nave": "5",
    "sección": "B",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Pere de Ribes",
    "nave": "5",
    "sección": "B",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Piera",
    "nave": "5",
    "sección": "B",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Martorell",
    "nave": "5",
    "sección": "B",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Masquefa",
    "nave": "5",
    "sección": "B",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "La Roca",
    "nave": "5",
    "sección": "B",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Montmeló",
    "nave": "5",
    "sección": "B",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Montornès",
    "nave": "5",
    "sección": "B",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vilanova del Vallès",
    "nave": "5",
    "sección": "B",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Palafolls",
    "nave": "5",
    "sección": "B",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Tordera",
    "nave": "5",
    "sección": "B",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Pineda",
    "nave": "5",
    "sección": "B",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Malgrat de Mar",
    "nave": "5",
    "sección": "B",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Margarida de Montbui",
    "nave": "5",
    "sección": "B",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Capellades",
    "nave": "5",
    "sección": "B",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vilanova del Camí",
    "nave": "5",
    "sección": "B",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Palautordera",
    "nave": "5",
    "sección": "B",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sant Celoni",
    "nave": "5",
    "sección": "B",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Llinars",
    "nave": "5",
    "sección": "B",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Antoni de Vilamajor",
    "nave": "5",
    "sección": "B",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cubelles",
    "nave": "5",
    "sección": "B",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Boi",
    "nave": "5",
    "sección": "B",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Coloma de Cervelló",
    "nave": "5",
    "sección": "B",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sant Vicenç dels Horts",
    "nave": "5",
    "sección": "B",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Torrelles",
    "nave": "5",
    "sección": "B",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Esplugues",
    "nave": "5",
    "sección": "B",
    "posición": "10",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cornellà de Llobregat",
    "nave": "5",
    "sección": "B",
    "posición": "10",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Joan Despí",
    "nave": "5",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Feliu de Llobregat",
    "nave": "5",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Just Desvern",
    "nave": "5",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Montgat",
    "nave": "5",
    "sección": "C",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Tiana",
    "nave": "5",
    "sección": "C",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Dosrius",
    "nave": "5",
    "sección": "C",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Argentona",
    "nave": "5",
    "sección": "C",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Masnou",
    "nave": "5",
    "sección": "C",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Alella",
    "nave": "5",
    "sección": "C",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Teia",
    "nave": "5",
    "sección": "C",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Molins de Rei",
    "nave": "5",
    "sección": "C",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Pallejà",
    "nave": "5",
    "sección": "C",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Andreu de la Barca",
    "nave": "5",
    "sección": "C",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Papiol",
    "nave": "5",
    "sección": "C",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Palma de Cervelló",
    "nave": "5",
    "sección": "D",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Corbera de Llobregat",
    "nave": "5",
    "sección": "D",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vallirana",
    "nave": "5",
    "sección": "D",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cervelló",
    "nave": "5",
    "sección": "D",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Premià de Mar",
    "nave": "5",
    "sección": "D",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Premià de Dalt",
    "nave": "5",
    "sección": "D",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vilassar de Dalt",
    "nave": "5",
    "sección": "D",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cabrera",
    "nave": "5",
    "sección": "D",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cabrils",
    "nave": "5",
    "sección": "D",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sallent",
    "nave": "5",
    "sección": "D",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Castellterçol",
    "nave": "5",
    "sección": "D",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Caldes de Montbui",
    "nave": "5",
    "sección": "D",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Moià",
    "nave": "5",
    "sección": "D",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sant Feliu de Codines",
    "nave": "5",
    "sección": "D",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Igualada",
    "nave": "5",
    "sección": "D",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "St Cugat",
    "nave": "5",
    "sección": "D",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Valldoreix",
    "nave": "5",
    "sección": "D",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vilafranca",
    "nave": "5",
    "sección": "D",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Barcelona (use 6)",
    "nave": "5",
    "sección": "E",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "IKEA",
    "nave": "5",
    "sección": "E",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Mataró",
    "nave": "5",
    "sección": "E",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Vilassar de Mar",
    "nave": "5",
    "sección": "E",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Calella",
    "nave": "5",
    "sección": "E",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Arenys de Mar",
    "nave": "5",
    "sección": "E",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Canet",
    "nave": "5",
    "sección": "E",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Cebrià de Vallalta",
    "nave": "5",
    "sección": "E",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Pol de Mar",
    "nave": "5",
    "sección": "E",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Margarida i els Monjos",
    "nave": "5",
    "sección": "E",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Martí Sarroca",
    "nave": "5",
    "sección": "E",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Berga",
    "nave": "5",
    "sección": "E",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Baga",
    "nave": "5",
    "sección": "E",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Puig-Reig",
    "nave": "5",
    "sección": "E",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Navas",
    "nave": "5",
    "sección": "E",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Gironella",
    "nave": "5",
    "sección": "E",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Maria d’Oló",
    "nave": "5",
    "sección": "E",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Manresa",
    "nave": "5",
    "sección": "E",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Artés",
    "nave": "5",
    "sección": "E",
    "posición": "6",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Garriga",
    "nave": "5",
    "sección": "E",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Canovelles",
    "nave": "5",
    "sección": "E",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Franqueses",
    "nave": "5",
    "sección": "E",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "L'Ametlla",
    "nave": "5",
    "sección": "E",
    "posición": "7",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Bigues i Riells",
    "nave": "5",
    "sección": "E",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Lliçà d'amunt",
    "nave": "5",
    "sección": "E",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Lliçà de Vall",
    "nave": "5",
    "sección": "E",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Parets",
    "nave": "5",
    "sección": "E",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Eulàlia de Ronçana",
    "nave": "5",
    "sección": "E",
    "posición": "8",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Gelida",
    "nave": "5",
    "sección": "E",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Sadurní",
    "nave": "5",
    "sección": "E",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "St Pere de Riudebitlles",
    "nave": "5",
    "sección": "E",
    "posición": "9",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cerdanyola",
    "nave": "5",
    "sección": "E",
    "posición": "10",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Quirze",
    "nave": "5",
    "sección": "E",
    "posición": "10",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Bellaterra",
    "nave": "5",
    "sección": "F",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Barberà",
    "nave": "5",
    "sección": "F",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Badia",
    "nave": "5",
    "sección": "F",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Begues",
    "nave": "5",
    "sección": "F",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Gava",
    "nave": "5",
    "sección": "F",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Castelldefels",
    "nave": "5",
    "sección": "F",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "El Prat",
    "nave": "5",
    "sección": "F",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Viladecans",
    "nave": "5",
    "sección": "F",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Martorelles",
    "nave": "5",
    "sección": "F",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Fost",
    "nave": "5",
    "sección": "F",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Mollet",
    "nave": "5",
    "sección": "F",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Palau Solita",
    "nave": "5",
    "sección": "F",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Adrià",
    "nave": "5",
    "sección": "F",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "El Prat (URP)",
    "nave": "1",
    "sección": "",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Colón",
    "nave": "1",
    "sección": "",
    "posición": "2",
    "provincia": "",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "El Vendrell",
    "nave": "1",
    "sección": "",
    "posición": "3",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Calafell",
    "nave": "1",
    "sección": "",
    "posición": "4",
    "provincia": "Tarragona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Segur de Calafell",
    "nave": "1",
    "sección": "",
    "posición": "4",
    "provincia": "Tarragona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cunit",
    "nave": "1",
    "sección": "",
    "posición": "4",
    "provincia": "Tarragona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Palamós",
    "nave": "1",
    "sección": "",
    "posición": "5",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Palafrugell",
    "nave": "1",
    "sección": "",
    "posición": "5",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "La Bisbal d’Empordà",
    "nave": "1",
    "sección": "",
    "posición": "5",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sta Coloma de Farners",
    "nave": "1",
    "sección": "",
    "posición": "6",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Hostalric",
    "nave": "1",
    "sección": "",
    "posición": "6",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Arbúcies",
    "nave": "1",
    "sección": "",
    "posición": "6",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sant Hilari Sacalm",
    "nave": "1",
    "sección": "",
    "posición": "6",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Caldes de Malavella",
    "nave": "1",
    "sección": "",
    "posición": "7",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Maçanet",
    "nave": "1",
    "sección": "",
    "posición": "7",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Sils",
    "nave": "1",
    "sección": "",
    "posición": "7",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Llagostera",
    "nave": "1",
    "sección": "",
    "posición": "7",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vidreres",
    "nave": "1",
    "sección": "",
    "posición": "7",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Tossa de Mar",
    "nave": "1",
    "sección": "",
    "posición": "8",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Blanes",
    "nave": "1",
    "sección": "",
    "posición": "8",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Lloret de Mar",
    "nave": "1",
    "sección": "",
    "posición": "8",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Ribes de Freser",
    "nave": "1",
    "sección": "",
    "posición": "9",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Ripoll",
    "nave": "1",
    "sección": "",
    "posición": "9",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Campdevànol",
    "nave": "1",
    "sección": "",
    "posición": "9",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Calaf",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Lleida",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Fruitós",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Julià de Vilatorta",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Rubí",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Castellbisbal",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vic",
    "nave": "6",
    "sección": "B",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Masies de Voltregà",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Roda de Ter",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Ripollet",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Montcada i Reixac",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Vicenç de Castellet",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Olesa de Montserrat",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Castellbell i el Vilar",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Andreu de Llavaneres",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "St Vicenç de Montalt",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Arenys de Munt",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cardona",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Santpedor",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Súria",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Vacarisses",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Castellar",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Matadepera",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Cardedeu",
    "nave": "6",
    "sección": "C",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Granollers",
    "nave": "6",
    "sección": "C",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Sabadell (ur4, ur1)",
    "nave": "6",
    "sección": "A",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Terrassa (op, ur1, ur3)",
    "nave": "6",
    "sección": "A",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Vic",
    "nave": "6",
    "sección": "B",
    "posición": "1",
    "provincia": "Barcelona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Badalona (use, ur1)",
    "nave": "6",
    "sección": "B",
    "posición": "2",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Sabadell (use, ur2, ur3)",
    "nave": "6",
    "sección": "B",
    "posición": "3",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Terrassa (use, ur2)",
    "nave": "6",
    "sección": "B",
    "posición": "4",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Hospitalet",
    "nave": "6",
    "sección": "B",
    "posición": "5",
    "provincia": "Barcelona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Andorra",
    "nave": "3",
    "sección": "A",
    "posición": "1",
    "provincia": "",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  },
  {
    "pueblo": "Girona (resto)",
    "nave": "3",
    "sección": "A",
    "posición": "2",
    "provincia": "Girona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Girona (use)",
    "nave": "3",
    "sección": "A",
    "posición": "3",
    "provincia": "Girona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Girona (ur1)",
    "nave": "3",
    "sección": "A",
    "posición": "3",
    "provincia": "Girona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Salt",
    "nave": "3",
    "sección": "A",
    "posición": "4",
    "provincia": "Girona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Figueres",
    "nave": "3",
    "sección": "A",
    "posición": "4",
    "provincia": "Girona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Trade Inn",
    "nave": "3",
    "sección": "A",
    "posición": "4",
    "provincia": "Girona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Tarragona (use)",
    "nave": "3",
    "sección": "A",
    "posición": "5",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Tarragona (ur1)",
    "nave": "3",
    "sección": "A",
    "posición": "5",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Tarragona (ur2)",
    "nave": "3",
    "sección": "A",
    "posición": "5",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Reus",
    "nave": "3",
    "sección": "A",
    "posición": "6",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Tarragona (resto)",
    "nave": "3",
    "sección": "A",
    "posición": "7",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Sant Cugat (CTA)",
    "nave": "3",
    "sección": "A",
    "posición": "8",
    "provincia": "Lleida",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Sant Cugat (URP)",
    "nave": "3",
    "sección": "A",
    "posición": "9",
    "provincia": "Lleida",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Mora d'Ebre",
    "nave": "3",
    "sección": "B",
    "posición": "1",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Tortosa",
    "nave": "3",
    "sección": "B",
    "posición": "2",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Amposta",
    "nave": "3",
    "sección": "B",
    "posición": "3",
    "provincia": "Tarragona",
    "firma": "TRUE",
    "firma-domingo": "TRUE"
  },
  {
    "pueblo": "Puigcerda",
    "nave": "3",
    "sección": "B",
    "posición": "4",
    "provincia": "Girona",
    "firma": "FALSE",
    "firma-domingo": "FALSE"
  }
];