<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_courses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users'); // Referencia a la tabla users
            $table->foreignId('course_id')->constrained('courses'); // Referencia a la tabla courses
            $table->foreignId('status_id')->nullable()->constrained('user_course_statuses'); // Referencia a la tabla user_course_statuses
            $table->foreignId('receipt_id')->nullable()->constrained('receipts'); // Referencia a la tabla receipts
            $table->integer('rating')->nullable(); // Puntuación
            $table->boolean('favorite')->default(0); // Favorito
            $table->decimal('price_paid', 10, 2); // Precio pagado
            $table->timestamps(); // Incluye created_at y updated_at
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_courses');
    }
};