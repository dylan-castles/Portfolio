<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('chapters', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('chapter_number');
            $table->string('title');
            $table->text('description')->nullable(); // Descripción del capítulo
            $table->longText('content')->nullable(); // Contenido del capítulo (puede ser texto, video, etc.)
            $table->foreignId('course_id')->constrained('courses'); //  Clave foranea a la tabla courses
            $table->boolean('is_exam'); // Indica si el capítulo es un examen

            // Fecha de creación y actualización
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('chapters');
    }
};