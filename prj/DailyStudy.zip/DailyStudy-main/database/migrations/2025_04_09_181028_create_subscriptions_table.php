<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('subscriptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained(); // Clave foránea hacia la tabla "users"
            $table->foreignId('subscription_product_id')->constrained('subscription_products'); // Clave foránea hacia la tabla "subscription_products"
            $table->decimal('price_paid', 10, 2); // Precio pagado
            $table->dateTime('subscription_date')->nullable(); // Días de suscripción formato YYYY-MM-DD:HH:MM:SS
            $table->foreignId('receipt_id')->nullable()->constrained('receipts');
            $table->timestamps();
        });
    }
    
    public function down(): void
    {
        Schema::dropIfExists('subscriptions');
    }
};
