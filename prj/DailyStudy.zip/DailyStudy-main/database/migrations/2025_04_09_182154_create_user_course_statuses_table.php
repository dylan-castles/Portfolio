<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        /*
            ESTADOS
            1. Cart.
            2. Owned.
            3. In Progress.
            4. Completed.
            5. Redoing
         */
        Schema::create('user_course_statuses', function (Blueprint $table) {
            $table->id();
            $table->string('name');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_course_statuses');
    }
};
