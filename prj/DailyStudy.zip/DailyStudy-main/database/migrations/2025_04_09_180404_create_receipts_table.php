<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('receipts', function (Blueprint $table) {
            $table->id();
            $table->enum('payment_method', [
                'card', 'paypal', 'bizum', 'transaction', 
                'bank_transfer'
            ]);
            $table->string('session_id')->nullable();

            // Cuando se creo el recibo --> Para el historial
            $table->dateTime('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('receipts');
    }
};
