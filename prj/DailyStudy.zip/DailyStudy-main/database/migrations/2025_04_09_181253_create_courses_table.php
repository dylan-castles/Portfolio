<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('description');
            $table->decimal('price', 10, 2)->nullable();
            $table->bigInteger('coins')->default(0); // Model para el sistema de monedas, por defecto 0
            $table->enum('type', ['free', 'pay', 'premium']);

            $table->enum('status', ['draft', 'published', 'unpublished', 'review']); // Estado del curso

            // Clave foranea a la tabla de usuarios
            $table->foreignId('owner_id')->nullable()->constrained('users');

            // Clave foranea a la tabla de categorias
            $table->foreignId('subcategory_id')->constrained('subcategories')->nullable();

            // Fecha de subida del curso
            $table->timestamp('published_date')->nullable();

            // Fecha de creación
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('courses');
    }
};
