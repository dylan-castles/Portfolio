<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_course_id')->constrained('user_courses');
            $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP')); // Fecha de cuando al usuario se le ha dado el certificado
            $table->bigInteger('verification_code')->unique(); // Código único para verificar el certificado
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_certificates');
    }
};