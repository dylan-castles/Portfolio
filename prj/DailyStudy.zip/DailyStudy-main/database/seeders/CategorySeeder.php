<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('categories')->insert(['id' => 1, 'name' => 'Science', 'description' => '']);
        DB::table('categories')->insert(['id' => 2, 'name' => 'Technology and Engineering', 'description' => '']);
        DB::table('categories')->insert(['id' => 3, 'name' => 'Computer Science and IT', 'description' => '']);
        DB::table('categories')->insert(['id' => 4, 'name' => 'Art and Creativity', 'description' => '']);
        DB::table('categories')->insert(['id' => 5, 'name' => 'Business and Entrepreneurship', 'description' => '']);
        DB::table('categories')->insert(['id' => 6, 'name' => 'General Knowledge and Personal Development', 'description' => '']);
    }
}