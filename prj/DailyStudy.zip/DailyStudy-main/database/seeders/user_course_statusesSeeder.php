<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class user_course_statusesSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('user_course_statuses')->insert([
            ['id' => 1, 'name' => 'Cart'], 
            ['id' => 2, 'name' => 'Owned'],
            ['id' => 3, 'name' => 'In Progress'],
            ['id' => 4, 'name' => 'Completed'],
            ['id' => 5, 'name' => 'Redoing'],
        ]);
    }
}