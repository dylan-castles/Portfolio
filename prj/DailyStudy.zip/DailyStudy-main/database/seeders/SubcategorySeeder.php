<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubcategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('subcategories')->insert(['name' => 'Biology', 'description' => '', 'category_id' => 1]);
        DB::table('subcategories')->insert(['name' => 'Mathematics', 'description' => '', 'category_id' => 1]);
        DB::table('subcategories')->insert(['name' => 'Physics', 'description' => '', 'category_id' => 1]);
        DB::table('subcategories')->insert(['name' => 'Chemistry', 'description' => '', 'category_id' => 1]);
        DB::table('subcategories')->insert(['name' => 'Medicine / Health Sciences', 'description' => '', 'category_id' => 1]);

        DB::table('subcategories')->insert(['name' => 'Electronics', 'description' => '', 'category_id' => 2]);
        DB::table('subcategories')->insert(['name' => 'Industrial Technology', 'description' => '', 'category_id' => 2]);
        DB::table('subcategories')->insert(['name' => 'Technical Drawing', 'description' => '', 'category_id' => 2]);
        DB::table('subcategories')->insert(['name' => 'Robotics', 'description' => '', 'category_id' => 2]);
        DB::table('subcategories')->insert(['name' => 'Basic Engineering', 'description' => '', 'category_id' => 2]);

        DB::table('subcategories')->insert(['name' => 'Programming', 'description' => '', 'category_id' => 3]);
        DB::table('subcategories')->insert(['name' => 'Frontend Development', 'description' => '', 'category_id' => 3]);
        DB::table('subcategories')->insert(['name' => 'Backend Development', 'description' => '', 'category_id' => 3]);
        DB::table('subcategories')->insert(['name' => 'Cybersecurity', 'description' => '', 'category_id' => 3]);
        DB::table('subcategories')->insert(['name' => 'Networking', 'description' => '', 'category_id' => 3]);
        DB::table('subcategories')->insert(['name' => 'Operating Systems', 'description' => '', 'category_id' => 3]);
        DB::table('subcategories')->insert(['name' => 'Databases', 'description' => '', 'category_id' => 3]);

        DB::table('subcategories')->insert(['name' => 'Music', 'description' => '', 'category_id' => 4]);
        DB::table('subcategories')->insert(['name' => 'Drawing', 'description' => '', 'category_id' => 4]);
        DB::table('subcategories')->insert(['name' => 'Photography', 'description' => '', 'category_id' => 4]);
        DB::table('subcategories')->insert(['name' => 'Graphic Design', 'description' => '', 'category_id' => 4]);
        DB::table('subcategories')->insert(['name' => 'Video Editing', 'description' => '', 'category_id' => 4]);

        DB::table('subcategories')->insert(['name' => 'Business Management', 'description' => '', 'category_id' => 5]);
        DB::table('subcategories')->insert(['name' => 'Finance', 'description' => '', 'category_id' => 5]);
        DB::table('subcategories')->insert(['name' => 'Marketing', 'description' => '', 'category_id' => 5]);
        DB::table('subcategories')->insert(['name' => 'Digital Entrepreneurship', 'description' => '', 'category_id' => 5]);
        DB::table('subcategories')->insert(['name' => 'Business Models', 'description' => '', 'category_id' => 5]);

        DB::table('subcategories')->insert(['name' => 'Languages', 'description' => '', 'category_id' => 6]);
        DB::table('subcategories')->insert(['name' => 'History', 'description' => '', 'category_id' => 6]);
        DB::table('subcategories')->insert(['name' => 'Philosophy', 'description' => '', 'category_id' => 6]);
        DB::table('subcategories')->insert(['name' => 'Personal Development', 'description' => '', 'category_id' => 6]);
        DB::table('subcategories')->insert(['name' => 'Health and Wellness', 'description' => '', 'category_id' => 6]);
    }
}