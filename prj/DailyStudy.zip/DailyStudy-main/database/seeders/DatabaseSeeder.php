<?php

namespace Database\Seeders;

use App\Models\SubscriptionProduct;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Ejecuta los seeders de la base de datos.
     */
    public function run(): void {
        // Ejecutamos los seeders
        $this->call([
            CategorySeeder::class,
            SubcategorySeeder::class,
            RoleSeeder::class,
            SubscriptionProductSeeder::class,
            UserSeeder::class,
            SubscriptionSeeder::class,
            CourseSeeder::class,
            ChapterSeeder::class,
            ExerciseSeeder::class,
            OptionsSeeder::class,
            user_course_statusesSeeder::class,
            PruebasSeeder::class,
            ForumSeeder::class,
        ]);
    }
}