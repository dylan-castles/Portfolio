<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubscriptionProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('subscription_products')->insert([
            'name' => 'Free',
            'description' => 'Get started with access to free courses and basic platform features. Ideal for exploring the platform with no cost or time limitation.',
            'price' => 0.00,
            'stripe_price_id' => NULL,
            'subscription_days' => null, // no expiration
        ]);

        DB::table('subscription_products')->insert([
            'name' => 'Premium',
            'description' => 'Unlock full access to all courses, exclusive content, advanced learning tools, and priority support for 30 days. Perfect for active learners.',
            'price' => 19.99,
            'stripe_price_id' => 'price_1RHNURPKrNtZVTQtCRHOXbNe',
            'subscription_days' => 30,
        ]);

        DB::table('subscription_products')->insert([
            'name' => 'Company',
            'description' => 'Designed for teams and businesses. Includes multiple user seats, advanced analytics, progress tracking, admin tools, and full access to all content for 30 days.',
            'price' => 99.99,
            'stripe_price_id' => 'price_1RHNV0PKrNtZVTQtGxHxotGr',
            'subscription_days' => 30,
        ]);
    }
}