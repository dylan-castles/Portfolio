<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class OptionsSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('options')->insert([
            // Exercise 1: PHP Opening Tag (radio)
            ['exercise_id' => 1, 'answer' => '<?php',           'is_correct' => true],
            ['exercise_id' => 1, 'answer' => '<script>',         'is_correct' => false],
            ['exercise_id' => 1, 'answer' => '<php>',            'is_correct' => false],
            ['exercise_id' => 1, 'answer' => '<?=',             'is_correct' => false],

            // Exercise 2: Echo Statement (input)
            ['exercise_id' => 2, 'answer' => 'echo "Hello";',   'is_correct' => true],

            // Exercise 3: Declare Variable (input)
            ['exercise_id' => 3, 'answer' => '$name = "";',      'is_correct' => true],

            // Exercise 4: Valid Operators (checkbox)
            ['exercise_id' => 4, 'answer' => '+',                'is_correct' => true],
            ['exercise_id' => 4, 'answer' => '++',               'is_correct' => true],
            ['exercise_id' => 4, 'answer' => '--',               'is_correct' => true],
            ['exercise_id' => 4, 'answer' => '//',               'is_correct' => false],

            // Exercise 5: Single-line Comment (radio)
            ['exercise_id' => 5, 'answer' => '// comment',       'is_correct' => true],
            ['exercise_id' => 5, 'answer' => '/* comment */',    'is_correct' => false],
            ['exercise_id' => 5, 'answer' => '<!-- comment -->', 'is_correct' => false],
            ['exercise_id' => 5, 'answer' => '# comment',        'is_correct' => false],

            // Exercise 6: Function Keyword (input)
            ['exercise_id' => 6, 'answer' => 'function',         'is_correct' => true],

            // Exercise 7: Logical AND (input)
            ['exercise_id' => 7, 'answer' => '&&',               'is_correct' => true],

            // Exercise 8: Loop Structures (checkbox)
            ['exercise_id' => 8, 'answer' => 'for',              'is_correct' => true],
            ['exercise_id' => 8, 'answer' => 'while',           'is_correct' => true],
            ['exercise_id' => 8, 'answer' => 'foreach',         'is_correct' => true],
            ['exercise_id' => 8, 'answer' => 'loop',            'is_correct' => false],

            // Exercise 9: String Length Function (radio)
            ['exercise_id' => 9, 'answer' => 'strlen()',         'is_correct' => true],
            ['exercise_id' => 9, 'answer' => 'strlength()',      'is_correct' => false],
            ['exercise_id' => 9, 'answer' => 'length()',         'is_correct' => false],
            ['exercise_id' => 9, 'answer' => 'count()',          'is_correct' => false],

            // Exercise 10: Array Syntax (checkbox)
            ['exercise_id' => 10, 'answer' => 'array()',         'is_correct' => true],
            ['exercise_id' => 10, 'answer' => '[]',              'is_correct' => true],
            ['exercise_id' => 10, 'answer' => '{}',              'is_correct' => false],
            ['exercise_id' => 10, 'answer' => 'new Array()',     'is_correct' => false],

            // Exercise 11: Print Statement (input)
            ['exercise_id' => 11, 'answer' => 'print("Hello, Python!")', 'is_correct' => true],

            // Exercise 12: Indentation Purpose (radio)
            ['exercise_id' => 12, 'answer' => 'Define code blocks',      'is_correct' => true],
            ['exercise_id' => 12, 'answer' => 'Mark comments',           'is_correct' => false],
            ['exercise_id' => 12, 'answer' => 'Indent SQL queries',      'is_correct' => false],
            ['exercise_id' => 12, 'answer' => 'Align text only',         'is_correct' => false],

            // Exercise 13: Built-in Types (checkbox)
            ['exercise_id' => 13, 'answer' => 'int',             'is_correct' => true],
            ['exercise_id' => 13, 'answer' => 'str',             'is_correct' => false],
            ['exercise_id' => 13, 'answer' => 'list',            'is_correct' => true],
            ['exercise_id' => 13, 'answer' => 'float',           'is_correct' => true],
            ['exercise_id' => 13, 'answer' => 'char',            'is_correct' => false],

            // Exercise 14: Check Type (input)
            ['exercise_id' => 14, 'answer' => 'isinstance(x, int)',     'is_correct' => true],

            // Exercise 15: Define Function (input)
            ['exercise_id' => 15, 'answer' => 'def',                      'is_correct' => true],

            // Exercise 16: Loop Keyword (radio)
            ['exercise_id' => 16, 'answer' => 'for',                     'is_correct' => true],
            ['exercise_id' => 16, 'answer' => 'loop',                    'is_correct' => false],
            ['exercise_id' => 16, 'answer' => 'iterate',                 'is_correct' => false],
            ['exercise_id' => 16, 'answer' => 'while',                   'is_correct' => true],

            // Exercise 17: List Comprehension (input)
            ['exercise_id' => 17, 'answer' => '[i*i for i in range(1,6)]', 'is_correct' => true],

            // Exercise 18: Boolean Operators (checkbox)
            ['exercise_id' => 18, 'answer' => 'and',                   'is_correct' => true],
            ['exercise_id' => 18, 'answer' => 'or',                    'is_correct' => true],
            ['exercise_id' => 18, 'answer' => '&&',                    'is_correct' => false],
            ['exercise_id' => 18, 'answer' => 'not',                   'is_correct' => true],

            // Exercise 19: Import Module (input)
            ['exercise_id' => 19, 'answer' => 'import os',             'is_correct' => true],

            // Exercise 20: Dictionary Syntax (radio)
            ['exercise_id' => 20, 'answer' => '{"key": "value"}',      'is_correct' => true],
            ['exercise_id' => 20, 'answer' => 'dict(key:value)',       'is_correct' => false],
            ['exercise_id' => 20, 'answer' => '["key":"value"]',       'is_correct' => false],
            ['exercise_id' => 20, 'answer' => 'new dict()',           'is_correct' => false],
        ]);
    }
}