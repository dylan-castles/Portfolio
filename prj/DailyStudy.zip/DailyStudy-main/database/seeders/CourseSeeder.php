<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CourseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('courses')->insert([

            // Category 1: Science & Health
            [
                'title'          => 'Foundations of Cellular Biology',
                'description'    => 'A comprehensive course to master the basics of cellular biology.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'unpublished',
                'owner_id'       => 1,
                'subcategory_id' => 1,  // Biology
                'published_date' => now(),
            ],
            [
                'title'          => 'Human Genetics: Introduction',
                'description'    => 'Learn the fundamentals of human genetics with confidence.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'premium',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 5,  // Medicine / Health Sciences
                'published_date' => null,
            ],
            [
                'title'          => 'Algebra from Scratch',
                'description'    => 'Master the basics of algebra step by step.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'draft',
                'owner_id'       => 1,
                'subcategory_id' => 2,  // Mathematics
                'published_date' => null,
            ],
            [
                'title'          => 'Basic Differential Calculus',
                'description'    => 'A clear introduction to the fundamentals of differential calculus.',
                'price'          => 30,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'unpublished',
                'owner_id'       => 1,
                'subcategory_id' => 2,  // Mathematics
                'published_date' => null,
            ],
            [
                'title'          => 'Physics for Beginners',
                'description'    => 'Understand the key concepts of physics from the ground up.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'review',
                'owner_id'       => 1,
                'subcategory_id' => 3,  // Physics
                'published_date' => now(),
            ],
            [
                'title'          => 'Simplified Classical Mechanics',
                'description'    => 'An accessible guide to the principles of classical mechanics.',
                'price'          => 45,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 3,  // Physics
                'published_date' => now(),
            ],
            [
                'title'          => 'Introduction to General Chemistry',
                'description'    => 'Learn the foundations of general chemistry with practical examples.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 4,  // Chemistry
                'published_date' => now(),
            ],
            [
                'title'          => 'Chemical Reactions and Bonds',
                'description'    => 'Explore the world of chemical reactions and chemical bonding.',
                'price'          => 20,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 4,  // Chemistry
                'published_date' => now(),
            ],
            [
                'title'          => 'Basic Human Anatomy',
                'description'    => 'A friendly introduction to the structures of the human body.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 5,  // Medicine / Health Sciences
                'published_date' => now(),
            ],
            [
                'title'          => 'Introduction to Nutrition',
                'description'    => 'Learn the principles of nutrition for a healthy lifestyle.',
                'price'          => 35,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 5,  // Medicine / Health Sciences
                'published_date' => now(),
            ],

            // Category 2: Engineering & Tech
            [
                'title'          => 'Digital Electronics for Everyone',
                'description'    => 'Understand digital electronics fundamentals with hands-on examples.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 6,  // Electronics
                'published_date' => now(),
            ],
            [
                'title'          => 'Electronic Components and Their Functions',
                'description'    => 'Learn how transistors, resistors, capacitors and more actually work.',
                'price'          => 22,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 6,  // Electronics
                'published_date' => now(),
            ],
            [
                'title'          => 'Fundamentals of Automation',
                'description'    => 'Discover automation principles and real-world applications.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 7,  // Industrial Technology
                'published_date' => now(),
            ],
            [
                'title'          => 'Manufacturing Processes',
                'description'    => 'From casting to CNC, learn key manufacturing techniques.',
                'price'          => 40,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 7,  // Industrial Technology
                'published_date' => now(),
            ],
            [
                'title'          => 'Technical Drawing with AutoCAD',
                'description'    => 'Master AutoCAD tools to produce accurate technical drawings.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 8,  // Technical Drawing
                'published_date' => now(),
            ],
            [
                'title'          => 'ISO Standards in Blueprinting',
                'description'    => 'Learn the ISO conventions for professional blueprint creation.',
                'price'          => 28,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 8,  // Technical Drawing
                'published_date' => now(),
            ],
            [
                'title'          => 'Introduction to Educational Robotics',
                'description'    => 'Get started with building and programming simple robots.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 9,  // Robotics
                'published_date' => now(),
            ],
            [
                'title'          => 'Robot Programming with Arduino',
                'description'    => 'Write Arduino sketches to control motors, sensors, and actuators.',
                'price'          => 32,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 9,  // Robotics
                'published_date' => now(),
            ],
            [
                'title'          => 'Principles of Engineering',
                'description'    => 'Core concepts across mechanical, electrical, and civil engineering.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 10, // Basic Engineering
                'published_date' => now(),
            ],
            [
                'title'          => 'Mathematics for Engineers',
                'description'    => 'Applied math techniques every engineer should know.',
                'price'          => 29,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 10, // Basic Engineering
                'published_date' => now(),
            ],

            // Category 3: Software & IT
            [
                'title'          => 'Complete PHP Course',
                'description'    => 'A hands-on path to master PHP and build dynamic web apps.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 13, // Backend Development
                'published_date' => now(),
            ],
            [
                'title'          => 'Introduction to Python',
                'description'    => 'Learn Python syntax, data structures, and write your first scripts.',
                'price'          => 35,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 11, // Programming
                'published_date' => now(),
            ],
            [
                'title'          => 'HTML & CSS from Scratch',
                'description'    => 'Build and style your first web pages, step-by-step.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 12, // Frontend Development
                'published_date' => now(),
            ],
            [
                'title'          => 'Complete JavaScript Course',
                'description'    => 'Learn modern JavaScript, DOM manipulation, and interactive apps.',
                'price'          => 40,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 12, // Frontend Development
                'published_date' => now(),
            ],
            [
                'title'          => 'Node.js & Express for Beginners',
                'description'    => 'Create servers, define routes, and build RESTful APIs.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 13, // Backend Development
                'published_date' => now(),
            ],
            [
                'title'          => 'Intermediate Laravel',
                'description'    => 'Master routing, Eloquent ORM, middleware, and more.',
                'price'          => 45,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 13, // Backend Development
                'published_date' => now(),
            ],
            [
                'title'          => 'Basic Cybersecurity',
                'description'    => 'Understand common threats and best practices to secure systems.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 14, // Cybersecurity
                'published_date' => now(),
            ],
            [
                'title'          => 'TCP/IP in Practice',
                'description'    => 'Learn the OSI model, IP addressing, subnets, and real-world examples.',
                'price'          => 38,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 15, // Networking
                'published_date' => now(),
            ],
            [
                'title'          => 'Linux from Scratch',
                'description'    => 'Master the command line, file permissions, and essential Linux tools.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 16, // Operating Systems
                'published_date' => now(),
            ],
            [
                'title'          => 'SQL for Beginners',
                'description'    => 'Learn SELECT, WHERE, JOINs, and build your first database queries.',
                'price'          => 32,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 17, // Databases
                'published_date' => now(),
            ],

            // Category 4: Creative Arts
            [
                'title'          => 'Learn Guitar Step by Step',
                'description'    => 'From chords to melodies, get playing in no time.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 18, // Music
                'published_date' => now(),
            ],
            [
                'title'          => 'Perspective & Shading',
                'description'    => 'Master depth, light, and shadow in your drawings.',
                'price'          => 28,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 19, // Drawing
                'published_date' => now(),
            ],
            [
                'title'          => 'Lightroom Editing',
                'description'    => 'Enhance your photos with professional adjustments and presets.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 20, // Photography
                'published_date' => now(),
            ],
            [
                'title'          => 'Illustrator for Beginners',
                'description'    => 'Learn vector tools, shapes, and create stunning graphics.',
                'price'          => 34,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 21, // Graphic Design
                'published_date' => now(),
            ],
            [
                'title'          => 'Adobe Premiere Editing',
                'description'    => 'Cut, transition, and color-grade your first video.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 22, // Video Editing
                'published_date' => now(),
            ],

            // Category 5: Business & Management
            [
                'title'          => 'Introduction to Management',
                'description'    => 'Fundamentals of planning, organizing, and leading teams.',
                'price'          => 26,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 23, // Business Management
                'published_date' => now(),
            ],
            [
                'title'          => 'Smart Personal Finance',
                'description'    => 'Budget, save, and invest wisely to secure your future.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 24, // Finance
                'published_date' => now(),
            ],
            [
                'title'          => 'Digital Marketing from Scratch',
                'description'    => 'SEO, social ads, and strategy to grow your brand online.',
                'price'          => 42,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 25, // Marketing
                'published_date' => now(),
            ],
            [
                'title'          => 'Launch Your Startup in 30 Days',
                'description'    => 'From idea to MVP: step-by-step guidance over 30 days.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 26, // Digital Entrepreneurship
                'published_date' => now(),
            ],
            [
                'title'          => 'Applied Lean Startup',
                'description'    => 'Validate ideas quickly and build products users love.',
                'price'          => 38,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 27, // Business Models
                'published_date' => now(),
            ],

            // Category 6: Humanities & Self-Improvement
            [
                'title'          => 'English A1 for Beginners',
                'description'    => 'Build basic vocabulary, grammar, and conversational skills.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 28, // Languages
                'published_date' => now(),
            ],
            [
                'title'          => 'Great Ancient Civilizations',
                'description'    => 'Explore Egypt, Greece, Rome and their cultural legacies.',
                'price'          => 29,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 29, // History
                'published_date' => now(),
            ],
            [
                'title'          => 'Western Philosophy from Socrates',
                'description'    => 'Trace ideas from antiquity through modern thought.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 30, // Philosophy
                'published_date' => now(),
            ],
            [
                'title'          => 'Time Management & Productivity',
                'description'    => 'Techniques to optimize your day and achieve your goals.',
                'price'          => 31,
                'coins'          => 50,
                'type'           => 'pay',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 31, // Personal Development
                'published_date' => now(),
            ],
            [
                'title'          => 'Yoga for Beginners',
                'description'    => 'Learn foundational poses, breathing, and sequences for wellness.',
                'price'          => 0,
                'coins'          => 50,
                'type'           => 'free',
                'status'        => 'published',
                'owner_id'       => 1,
                'subcategory_id' => 32, // Health and Wellness
                'published_date' => now(),
            ],

        ]);
    }
}