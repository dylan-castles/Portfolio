<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = [
            [
                'name' => 'Admin',
                'surname' => 'Admin',
                'username' => 'admin',
                'email' => 'admin@example.com',
                'role_id' => 1, // Admin
            ],
            [
                'name' => 'Dylan',
                'surname' => 'Castles',
                'username' => 'dcastles',
                'email' => 'dylan@example.com',
                'role_id' => 3, // Student
            ],
            [
                'name' => 'Marc',
                'surname' => 'Colome',
                'username' => 'mcolome',
                'email' => 'marc@example.com',
                'role_id' => 3, // Student
            ],
            [
                'name' => 'Manav',
                'surname' => 'Sharma',
                'username' => 'msharma',
                'email' => 'manav@example.com',
                'role_id' => 2, // Teacher
            ],
            [
                'name' => 'Pol',
                'surname' => 'Marc',
                'username' => 'pmarc',
                'email' => 'pol@example.com',
                'role_id' => 3, // Student
            ],
            [
                'name' => 'Revisor',
                'surname' => 'Revisor',
                'username' => 'revisor',
                'email' => 'revisor@example.com',
                'role_id' => 4, // Revisor
            ],
        ];

        foreach ($users as $user) {
            DB::table('users')->insert([
                'name'              => $user['name'],
                'surname'           => $user['surname'],
                'username'          => $user['username'],
                'email'             => $user['email'],
                'password'          => bcrypt('Password1234!'), // bcrypt60
                'coins'             => 0,
                'status'            => 'active',
                'completed_courses' => 0,
                'role_id'           => $user['role_id'],
            ]);
        }
    }
}