<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PruebasSeeder extends Seeder
{
    public function run(): void
    {
        $now = now();
        $data = [];

        for ($i = 1; $i <= 45; $i++) {
            $data[] = [
                'user_id'    => 2,
                'course_id'  => $i,
                'status_id'  => 2,       // Status "Owned"
                'receipt_id' => null,
                'price_paid' => 0,
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        DB::table('user_courses')->insert($data);
    }
}
