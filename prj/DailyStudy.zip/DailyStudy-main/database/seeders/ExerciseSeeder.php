<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ExerciseSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('exercises')->insert([
            //
            // Course 21: Complete PHP Course
            //

            // Chapter 1 (chapter_id = 1)
            [
                'exercise_number' => 1,
                'title'           => 'PHP Opening Tag',
                'content'         => 'Which tag starts a PHP block?',
                'chapter_id'      => 1,
                'type'            => 'radio',
            ],
            [
                'exercise_number' => 2,
                'title'           => 'Echo Statement',
                'content'         => 'Type exactly: echo "Hello";',
                'chapter_id'      => 1,
                'type'            => 'input',
            ],

            // Chapter 2 (chapter_id = 2)
            [
                'exercise_number' => 1,
                'title'           => 'Declare Variable',
                'content'         => 'How do you declare a variable named $name?',
                'chapter_id'      => 2,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 2,
                'title'           => 'Valid Operators',
                'content'         => 'Select all valid PHP operators:',
                'chapter_id'      => 2,
                'type'            => 'checkbox',
            ],

            // PHP Final Exam (chapter_id = 3)
            [
                'exercise_number' => 1,
                'title'           => 'Single-line Comment',
                'content'         => 'Which of these is a valid single-line PHP comment?',
                'chapter_id'      => 3,
                'type'            => 'radio',
            ],
            [
                'exercise_number' => 2,
                'title'           => 'Function Keyword',
                'content'         => 'Type exactly: function',
                'chapter_id'      => 3,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 3,
                'title'           => 'Logical AND',
                'content'         => 'Type exactly: &&',
                'chapter_id'      => 3,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 4,
                'title'           => 'Loop Structures',
                'content'         => 'Select all valid PHP loop constructs:',
                'chapter_id'      => 3,
                'type'            => 'checkbox',
            ],
            [
                'exercise_number' => 5,
                'title'           => 'String Length Function',
                'content'         => 'Which function returns the length of a string?',
                'chapter_id'      => 3,
                'type'            => 'radio',
            ],
            [
                'exercise_number' => 6,
                'title'           => 'Array Syntax',
                'content'         => 'Select the correct ways to define an array:',
                'chapter_id'      => 3,
                'type'            => 'checkbox',
            ],

            //
            // Course 22: Introduction to Python
            //

            // Chapter 1 (chapter_id = 4)
            [
                'exercise_number' => 1,
                'title'           => 'Print Statement',
                'content'         => 'Type exactly: print("Hello, Python!")',
                'chapter_id'      => 4,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 2,
                'title'           => 'Indentation Purpose',
                'content'         => 'Python uses indentation to define:',
                'chapter_id'      => 4,
                'type'            => 'radio',
            ],

            // Chapter 2 (chapter_id = 5)
            [
                'exercise_number' => 1,
                'title'           => 'Built-in Types',
                'content'         => 'Select Python built-in data types:',
                'chapter_id'      => 5,
                'type'            => 'checkbox',
            ],
            [
                'exercise_number' => 2,
                'title'           => 'Check Type',
                'content'         => 'Type exactly: isinstance(x, int)',
                'chapter_id'      => 5,
                'type'            => 'input',
            ],

            // Python Final Exam (chapter_id = 6)
            [
                'exercise_number' => 1,
                'title'           => 'Define Function',
                'content'         => 'Type exactly: def',
                'chapter_id'      => 6,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 2,
                'title'           => 'Loop Keyword',
                'content'         => 'Which keyword creates a loop?',
                'chapter_id'      => 6,
                'type'            => 'radio',
            ],
            [
                'exercise_number' => 3,
                'title'           => 'List Comprehension',
                'content'         => 'Type exactly: [i*i for i in range(1,6)]',
                'chapter_id'      => 6,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 4,
                'title'           => 'Boolean Operators',
                'content'         => 'Select Python boolean operators:',
                'chapter_id'      => 6,
                'type'            => 'checkbox',
            ],
            [
                'exercise_number' => 5,
                'title'           => 'Import Module',
                'content'         => 'Type exactly: import os',
                'chapter_id'      => 6,
                'type'            => 'input',
            ],
            [
                'exercise_number' => 6,
                'title'           => 'Dictionary Syntax',
                'content'         => 'Which syntax creates a dict?',
                'chapter_id'      => 6,
                'type'            => 'radio',
            ],
        ]);
    }
}