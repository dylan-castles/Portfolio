<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ChapterSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('chapters')->insert([

            // Course 21: Complete PHP Course
            [
                'chapter_number' => 1,
                'title'          => 'Introduction to PHP',
                'description'    => 'What PHP is and how it works in web development.',
                'content'        => '
                    <h1>Introduction to PHP</h1>
                    <p>PHP (Hypertext Preprocessor) is a popular server-side scripting language designed for web development. It is embedded into HTML and executed on the server, generating dynamic page content.</p>
                    <h2>History of PHP</h2>
                    <p>Originally created in 1994 by Rasmus Lerdorf as "Personal Home Page Tools", PHP has evolved into a full-featured language powering millions of websites and applications.</p>
                    <h2>How PHP Works</h2>
                    <p>When a client requests a PHP page, the web server passes it to the PHP interpreter. PHP processes the code, interacts with databases or other services if needed, and returns HTML to the client’s browser.</p>
                    <h2>Getting Started</h2>
                    <p>Install a local development environment like XAMPP or MAMP, place your <code>.php</code> files in the <code>htdocs</code> or <code>www</code> folder, and access them via <code>http://localhost/yourfile.php</code>.</p>
                    <h2>Basic Syntax</h2>
                    <p>PHP scripts start with <code>&lt;?php</code> and end with <code>?&gt;</code>. Statements end with a semicolon. Comments can be added with <code>//</code>, <code>#</code>, or <code>/* ... */</code>.</p>
                ',
                'course_id'      => 21,
                'is_exam'        => false,
            ],
            [
                'chapter_number' => 2,
                'title'          => 'Variables and Operators',
                'description'    => 'Working with variables, data types, and operators.',
                'content'        => '
                    <h1>PHP Variables and Operators</h1>
                    <p>Variables in PHP are containers for storing data values. Every variable starts with a dollar sign (<code>$</code>), followed by the name.</p>
                    <h4>Variable Naming Rules</h2>
                    <ul>
                        <li>Must begin with a letter or underscore.</li>
                        <li>Case-sensitive.</li>
                        <li>Examples: <code>$name</code>, <code>$_age</code>, <code>$total_price</code>.</li>
                    </ul>
                    <h2>Data Types</h2>
                    <ul>
                        <li><strong>String:</strong> Sequence of characters.</li>
                        <li><strong>Integer:</strong> Whole numbers.</li>
                        <li><strong>Float:</strong> Decimal numbers.</li>
                        <li><strong>Boolean:</strong> <code>true</code> or <code>false</code>.</li>
                        <li><strong>Array:</strong> Ordered map of values.</li>
                    </ul>
                    <h2>Operators</h2>
                    <p>PHP offers a variety of operators:</p>
                    <ul>
                        <li><strong>Arithmetic:</strong> <code>+</code>, <code>-</code>, <code>*</code>, <code>/</code>, <code>%</code>.</li>
                        <li><strong>Assignment:</strong> <code>=</code>, <code>+=</code>, <code>-=</code>.</li>
                        <li><strong>Comparison:</strong> <code>==</code>, <code>===</code>, <code>&lt;</code>, <code>&gt;</code>.</li>
                        <li><strong>Logical:</strong> <code>&amp;&amp;</code>, <code>||</code>, <code>!</code>.</li>
                    </ul>
                    <h2>Example</h2>
                    <pre><code>&lt;?php
$name = "Alice";
$age = 30;
$sum = $age + 5;
if ($sum &gt; 30) {
    echo "You are over 30!";
}
?&gt;
                    </code></pre>
                ',
                'course_id'      => 21,
                'is_exam'        => false,
            ],
            [
                'chapter_number' => 3,
                'title'          => 'PHP Final Exam',
                'description'    => 'Test your knowledge with this final exam.',
                'content'        => '
                    <h1>PHP Final Exam</h1>
                    <p>In this exam, you will be asked to demonstrate your understanding of PHP basics, variables, data types, and operators.</p>
                    <h2>Instructions</h2>
                    <ol>
                        <li>Answer each question clearly and accurately.</li>
                        <li>For input questions, enter the exact syntax as shown in examples.</li>
                        <li>There are no partial credits: ensure your responses match the expected output.</li>
                        <li>Good luck!</li>
                    </ol>
                ',
                'course_id'      => 21,
                'is_exam'        => true,
            ],

            // Course 22: Introduction to Python
            [
                'chapter_number' => 1,
                'title'          => 'Python from Scratch',
                'description'    => 'First steps with Python.',
                'content'        => '
                    <h1>Getting Started with Python</h1>
                    <p>Python is a high-level, interpreted language known for its readability and versatility. It\'s widely used in web development, data science, automation, and more.</p>
                    <h2>Installing Python</h2>
                    <p>Download Python from the official website (<a href="https://www.python.org/">python.org</a>) and follow the installation instructions for your operating system.</p>
                    <h2>Your First Python Script</h2>
                    <pre><code>print("Hello, World!")</code></pre>
                    <p>Save the above code in a file named <code>hello.py</code> and run it via <code>python hello.py</code> in your terminal.</p>
                    <h2>Interactive Mode</h2>
                    <p>Launch the Python REPL by typing <code>python</code> without any file. You can execute commands line by line.</p>
                ',
                'course_id'      => 22,
                'is_exam'        => false,
            ],
            [
                'chapter_number' => 2,
                'title'          => 'Data Types',
                'description'    => 'Using integers, strings, and lists.',
                'content'        => '
                    <h1>Python Data Types</h1>
                    <p>Python supports several built-in data types that you will use frequently.</p>
                    <h2>Numbers</h2>
                    <p><strong>Integers</strong> (e.g., <code>5</code>), <strong>Floats</strong> (e.g., <code>3.14</code>).</p>
                    <h2>Strings</h2>
                    <p>Text enclosed in quotes: <code>"Hello"</code> or <code>\'World\'</code>. Use methods like <code>.upper()</code>, <code>.split()</code>.</p>
                    <h2>Lists</h2>
                    <p>Ordered, mutable collections: <code>[1, 2, 3]</code>. Access items by index, slice lists, and use methods like <code>.append()</code>.</p>
                    <h2>Examples</h2>
                    <pre><code># Integer and float
x = 10
y = 2.5

# String
greeting = "Hello, Python!"

# List
numbers = [1, 2, 3, 4]
numbers.append(5)
print(numbers)
</code></pre>
                ',
                'course_id'      => 22,
                'is_exam'        => false,
            ],
            [
                'chapter_number' => 3,
                'title'          => 'Python Final Exam',
                'description'    => 'Test your knowledge with this exam.',
                'content'        => '
                    <h1>Python Final Exam</h1>
                    <p>This exam covers basic Python syntax, data types, and list operations. Make sure to answer each question precisely.</p>
                    <h2>Instructions</h2>
                    <ol>
                        <li>Provide the correct output or code snippet as required.</li>
                        <li>For list questions, show the resulting list exactly.</li>
                        <li>Ensure correct capitalization and punctuation.</li>
                        <li>Best of luck!</li>
                    </ol>
                ',
                'course_id'      => 22,
                'is_exam'        => true,
            ],
        ]);
    }
}