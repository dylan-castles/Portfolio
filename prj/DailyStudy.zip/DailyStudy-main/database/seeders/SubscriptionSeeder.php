<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SubscriptionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        {
            // Correos de los usuarios a los que se les asignará el plan Free
            $userEmails = [
                'dylan@example.com',
                'marc@example.com',
                'manav@example.com',
                'pol@example.com',
            ];
    
            foreach ($userEmails as $email) {
                $user = DB::table('users')->where('email', $email)->first();
    
                if ($user) {
                    DB::table('subscriptions')->insert([
                        'user_id'                 => $user->id,
                        'subscription_product_id' => 1, // Plan Free
                        'price_paid'              => 0.00,
                        // 'subscription_date'       => now(),
                        'receipt_id'              => null,
                        'created_at'              => now(),
                        'updated_at'              => now(),
                    ]);
                }
            }
        }
    }
}