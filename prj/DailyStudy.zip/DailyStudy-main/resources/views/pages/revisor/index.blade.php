@extends('layouts.appLayout')

@section('title', 'Revisor')

@section('content')
<div class="container my-3">
    <h1 class="mb-1 text-center text-white">Reviewer Panel</h1>
    @if(session('success') && session('course_id'))
    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        {{ session('success') }}, click <a href="{{ route('revisor.undo', session('course_id')) }}">here</a> to undo.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    @if(session('success2'))
    <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
        {{ session('success2') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    {{-- Cursos pendientes de revisión --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="text-white mb-3">Courses Pending to Review</h2>
    </div>

    <div class="row">
        @forelse($coursesToReview as $course)
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    <div class="card-body card-body-course">
                        <p class="card-text card-img">
                            <img src="{{ asset('img/coverIMG/cover' . $course->id . '.jpg') }}" class="imgCourse" alt="Course Cover" />
                        </p>
                        <div class="d-flex justify-content-between align-items-start padding-card gap-2">
                            <h5 class="card-title mb-0 flex-grow-1 text-truncate" style="max-width: 70%;">{{ $course->title }}</h5>
                        </div>

                        <p class="card-text padding-card d-flex justify-content-between">
                            <small class="text-muted">
                                Autor: {{ $course->owner->name }}
                            </small>
                            <small class="text-muted">
                                {{ \Carbon\Carbon::parse($course->created_at)->format('M d, Y') }}
                            </small>
                        </p>
                    </div>
                    <div class="card-footer">
                        <a href="{{ route('revisorCourse', ['id' => $course->id]) }}" class="btn btn1 w-100 mx-0">Review Course</a>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="alert alert-info text-center">
                    No pending courses to review! Go gamble all your school fundings <a href="https://www.bet365.es/">here!</a>
                </div>
            </div>
        @endforelse
    </div>
</div>

@push('scripts')
<script>
    // Aquí puedes añadir scripts específicos para el revisor si los necesitas
</script>
@endpush

@endsection
