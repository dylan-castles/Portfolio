@extends('layouts.appLayout')

@section('title', 'Discover')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/discover.css') }}">
@endpush

@section('content')
    <div class="container-fluid my-4 px-4">

        <!-- Breadcrumbs -->
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ route('homePage') }}">Home</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Discover
                    </li>
                </ol>
            </nav>
        </div>

        <!-- Page title -->
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h1 class="text-white fw-bold">Discover</h1>
                <span class="textOrange">Explore and find your course!</span>
            </div>
        </div>

        <!-- Search bar -->
        <div class="row mb-4">
            <div class="col-12 col-md-6 offset-md-3">
                <div class="input-group shadow-sm">
                    <input type="text" id="search-input" class="form-control border-end-0"
                        placeholder="Search for courses...">
                </div>
            </div>
        </div>

        <!-- Filtros y resultados -->
        <div class="row">

            <!-- Panel de Filtros -->
            <aside class="col-md-3">
                <div class="card border-0 shadow">
                    <div class="card-body pt-3">

                        <!-- Categorías como accordion -->
                        <div class="accordion mb-3" id="categoriesAccordion">
                            <div class="accordion-item border-0 shadow-sm p-3">
                                <h2 class="accordion-header">
                                    <button class="accordion-button bg-custom-purple fw-bold p-3 text-white" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseCategories">
                                        <i class="bi bi-tags me-2"></i> Categories
                                    </button>
                                </h2>
                                <div id="collapseCategories" class="accordion-collapse collapse show"
                                    data-bs-parent="#categoriesAccordion">
                                    <div class="accordion-body px-0 py-3">
                                        @foreach ($categoriesWithSubcategories as $category)
                                            <div class="mb-3">
                                                <!-- Checkbox principal -->
                                                <div class="form-check">
                                                    <input class="form-check-input parent-checkbox inputCheckboxPurple category-checkbox"
                                                        type="checkbox" id="category-{{ $category->id }}"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target="#subcategory-list-{{ $category->id }}"
                                                        aria-expanded="false"
                                                        aria-controls="subcategory-list-{{ $category->id }}"
                                                        value="{{ $category->id }}">
                                                    <label class="form-check-label fw-semibold"
                                                        for="category-{{ $category->id }}">
                                                        {{ $category->name }}
                                                    </label>
                                                </div>

                                                <!-- Subcategorías colapsables -->
                                                <div class="collapse mt-2 ms-3" id="subcategory-list-{{ $category->id }}">
                                                    @foreach ($category->subcategories as $subcategory)
                                                        <div class="form-check py-1">
                                                            <input class="form-check-input inputCheckboxPurple subcategory-checkbox"
                                                                type="checkbox" value="{{ $subcategory->id }}"
                                                                id="subcategory-{{ $subcategory->id }}"
                                                                value="{{ $subcategory->id }}">
                                                            <label class="form-check-label small"
                                                                for="subcategory-{{ $subcategory->id }}">   
                                                                {{ $subcategory->name }}
                                                            </label>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tipos de curso como accordion -->
                        <div class="accordion mb-3" id="typesAccordion">
                            <div class="accordion-item border-0 shadow-sm p-3">
                                <h2 class="accordion-header">
                                    <button class="accordion-button bg-custom-purple fw-bold p-3 text-white" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseTypes">
                                        <i class="bi bi-collection me-2"></i> Course Types
                                    </button>
                                </h2>
                                <div id="collapseTypes" class="accordion-collapse collapse show"
                                    data-bs-parent="#typesAccordion">
                                    <div class="accordion-body px-0 py-2">
                                        <div class="form-check py-1">
                                            <input class="form-check-input inputCheckboxPurple type-checkbox" type="checkbox"
                                                value="free" id="type-free">
                                            <label class="form-check-label d-flex align-items-center" for="type-free">
                                                <i class="bi bi-gift me-2 text-success"></i> Free
                                            </label>
                                        </div>
                                        <div class="form-check py-1">
                                            <input class="form-check-input inputCheckboxPurple type-checkbox" type="checkbox"
                                                value="premium" id="type-premium">
                                            <label class="form-check-label d-flex align-items-center" for="type-premium">
                                                <i class="bi bi-star-fill me-2 text-warning"></i> Premium
                                            </label>
                                        </div>
                                        <div class="form-check py-1">
                                            <input class="form-check-input inputCheckboxPurple type-checkbox" type="checkbox"
                                                value="pay" id="type-paid">
                                            <label class="form-check-label d-flex align-items-center" for="type-paid">
                                                <i class="bi bi-currency-dollar me-2 text-primary"></i> Pay
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Rango de precios como accordion -->
                        <div class="accordion mb-3" id="priceAccordion">
                            <div class="accordion-item border-0 shadow-sm p-3">
                                <h2 class="accordion-header shadow">
                                    <button class="accordion-button bg-custom-purple fw-bold p-3 text-white" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapsePrice">
                                        <i class="bi bi-currency-exchange me-2"></i> Price Range
                                    </button>
                                </h2>
                                <div id="collapsePrice" class="accordion-collapse collapse show"
                                    data-bs-parent="#priceAccordion">
                                    <div class="accordion-body px-0 py-3">
                                        <div class="price-input d-flex justify-content-between mb-3">
                                            <div class="price-field me-2">
                                                <label for="min-price" class="form-label small text-muted">Min</label>
                                                <div class="input-group">
                                                    <span class="input-group-text bg-custom-purple text-white">$</span>
                                                    <input type="number" id="min-price" class="form-control min-input inputTextLong"
                                                        value="0" min="0">
                                                </div>
                                            </div>
                                            <div class="price-field ms-2">
                                                <label for="max-price" class="form-label small text-muted">Max</label>
                                                <div class="input-group">
                                                    <span class="input-group-text bg-custom-purple text-white">$</span>
                                                    <input type="number" id="max-price" class="form-control max-input inputTextLong"
                                                        value="500" min="0">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="position-relative">
                                            <div class="slider">
                                                <div class="slider-track">
                                                    <div class="slider-range"></div>
                                                </div>
                                                <div class="form-range">
                                                    <input type="range" class="min-range range-input" min="0"
                                                        max="499" value="0" step="1" id="min-range">
                                                    <input type="range" class="max-range range-input" min="1"
                                                        max="500" value="500" step="1" id="max-range">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="button-filters-container">
                            {{-- Aplicar filtros --}}
                            <button id="btn-apply"
                                class="btn btn1 w-100 m-0 mb-3 d-flex align-items-center justify-content-center">
                                <i class="bi bi-funnel-fill me-2"></i> Apply filters
                            </button>
                            <!-- Limpiar filtros -->
                            <button id="btn-clear"
                                class="btn btn2 w-100 m-0 d-flex align-items-center justify-content-center">
                                <i class="bi bi-arrow-counterclockwise me-2"></i> Reset filters
                            </button>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Resultados -->
            <section class="col-md-9">
                <div class="row g-4" id="course-results">
                    {{-- Resultados dinámicos --}}
                </div>

                {{-- Paginación --}}
                <div class="row pagination justify-content-center mt-4" id="pagination">

                </div>
            </section>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="{{ asset('js/discover/discover.js') }}"></script>
@endpush
