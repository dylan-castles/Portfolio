@extends('layouts.appLayout')

@section('title', 'My profile')
@section('nav_title', 'My profile')

@section('content')
<div class="container my-5">
    <!-- Header con botones -->
    <div class="d-flex justify-content-between align-items-center mb-5">
        <a href="{{ route('homePage') }}" class="btn btn3">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
        <a href="{{ route('settingsPage') }}" class="btn btn3">
            <i class="fas fa-cog mx-0 "></i>
        </a>
    </div>

<!-- Información del usuario -->
<div class="card border-0 shadow-sm mb-5 rounded-4">
    <div class="card-header bg-light d-flex align-items-center border-bottom py-3 px-4">
        <i class="fas fa-user-circle text-primary fs-3 me-3"></i>
        <h5 class="mb-0 fw-bold text-dark">User Overview</h5>
    </div>
    <div class="card-body bg-white px-4 py-4">
        <div class="row g-4">
            <div class="col-md-6">
                <div>
                    <small class="text-muted">Name</small>
                    <p class="fs-5 fw-medium text-dark mb-0">{{ $user->name }}</p>
                </div>
                <div class="mt-3">
                    <small class="text-muted">Surname</small>
                    <p class="fs-5 fw-medium text-dark mb-0">{{ $user->surname }}</p>
                </div>
                <div class="mt-3">
                    <small class="text-muted">Username</small>
                    <p class="fs-5 fw-medium text-dark mb-0">{{ $user->username }}</p>
                </div>
            </div>
            <div class="col-md-6">
                <div>
                    <small class="text-muted">Email</small>
                    <p class="fs-5 fw-medium text-dark mb-0">
                        <i class="fas fa-envelope text-primary me-2"></i>{{ $user->email }}
                    </p>
                </div>
                <div class="mt-3">
                    <small class="text-muted">Coins</small>
                    <p class="fs-5 fw-medium text-dark mb-0">
                        <i class="fas fa-coins text-warning me-2"></i>{{ $user->coins }}
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>




    <!-- Grid de opciones -->
    <div class="row g-4">
        <div class="col-6 col-md-4 col-lg-2">
            <a href="{{route('myNotesPage')}}" class="text-decoration-none">
                <div class="card h-100 profile-card">
                    <div class="card-body text-center">
                        <i class="fas fa-sticky-note fa-2x text-primary mb-3"></i>
                        <h6 class="card-title mb-0">My notes</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-2">
            <a href="{{route('myAwardsPage')}}" class="text-decoration-none">
                <div class="card h-100 profile-card">
                    <div class="card-body text-center">
                        <i class="fas fa-trophy fa-2x text-warning mb-3"></i>
                        <h6 class="card-title mb-0">My awards</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-2">
            <a href="{{route('myCoursesPage')}}" class="text-decoration-none">
                <div class="card h-100 profile-card">
                    <div class="card-body text-center">
                        <i class="fas fa-graduation-cap fa-2x text-info mb-3"></i>
                        <h6 class="card-title mb-0">My courses</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-2">
            <a href="{{route('myPurchasesPage')}}" class="text-decoration-none">
                <div class="card h-100 profile-card">
                    <div class="card-body text-center">
                        <i class="fas fa-euro fa-2x text-success mb-3"></i>
                        <h6 class="card-title mb-0">My purchases</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-2">
            <a href="{{ route('auth.logout.submit') }}" class="text-decoration-none">
                <div class="card h-100 profile-card">
                    <div class="card-body text-center">
                        <i class="fas fa-sign-out-alt fa-2x text-danger mb-3"></i>
                        <h6 class="card-title mb-0">Logout</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-2">
            <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">
                <div class="card h-100 profile-card">
                    <div class="card-body text-center">
                        <i class="fas fa-user-times fa-2x text-danger mb-3"></i>
                        <h6 class="card-title mb-0">Delete account</h6>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>

<!-- Modal de confirmación -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-triangle me-2"></i>Confirmar eliminación
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="mb-0">¿Estás seguro de que deseas eliminar tu cuenta? Esta acción no se puede deshacer.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="{{ route('deleteAccount') }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash-alt me-2"></i>Sí, eliminar cuenta
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection