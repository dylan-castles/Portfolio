<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Teacher Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            padding: 20px;
            color: #333;
        }

        .email-container {
            max-width: 600px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #6f42c1;
        }

        .content p {
            font-size: 16px;
            line-height: 1.5;
            color: #333 !important;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #6f42c1;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
        }

        .footer {
            margin-top: 40px;
            font-size: 12px;
            color: #888;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>DailyStudy</h1>
        </div>

        <div class="content">
            <p><strong>Name:</strong> {{ $userName }}</p>
            <p><strong>Email:</strong> {{ $userEmail }}</p>

            @if ($linkedin)
                <p><strong>LinkedIn:</strong> <a href="{{ $linkedin }}">{{ $linkedin }}</a></p>
            @endif
            
            <p><strong>Curriculum:</strong> Attached</p>
            <p><strong>Portfolio:</strong> Attached</p>

            <div style="text-align: center;">
                <a href="{{ url('/admin/crudUsuarios') }}" class="btn" style="color: white;">Access Admin Panel</a>
            </div>
        </div>

        <div class="footer">
            This is an automated notification from DailyStudy.<br>
            &copy; {{ date('Y') }} DailyStudy
        </div>
    </div>
</body>
</html>