<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Password Reset - DailyStudy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            padding: 20px;
            color: #333;
        }

        .content p {
            font-size: 16px;
            line-height: 1.5;
            color: #333 !important; /* Fuerza el color gris oscuro */
        }

        .content strong {
            color: #333 !important; /* Asegura que no se vea en lila */
        }

        .email-container {
            max-width: 600px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #6f42c1;
        }

        .content p {
            font-size: 16px;
            line-height: 1.5;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            background-color: #6f42c1;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
        }

        .footer {
            margin-top: 40px;
            font-size: 12px;
            color: #888;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>DailyStudy</h1>
        </div>

        <div class="content">
            <p><strong>Name:</strong> {{ $userName }}</p>
            <p><strong>Email:</strong> {{ $userEmail }}</p>

            <p>You have requested to reset your password on DailyStudy.</p>
            <p>Click the button below to create a new password:</p>

            <div style="text-align: center;">
                <a href="{{ url('/reset-password/' . $token) }}" class="btn" style="color: white;">Reset Password</a>
            </div>
        </div>
        <div class="footer">
            If you didn’t request a password reset, you can ignore this email.<br>
            &copy; {{ date('Y') }} DailyStudy
        </div>
    </div>
</body>
</html>
