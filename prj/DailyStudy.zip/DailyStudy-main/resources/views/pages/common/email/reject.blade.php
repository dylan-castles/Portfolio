Buenos dias {{ $userName }}, hemos rechazado tu curso ({{ $courseTitle }}) por las siguientes causas:

{{ $messageContent }}