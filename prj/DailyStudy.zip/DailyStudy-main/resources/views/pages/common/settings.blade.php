@extends('layouts.appLayout')

@section('title', 'Settings')
@section('nav_title', 'Settings')

@section('content')
<div class="container my-4">

    <!-- Breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">My Profile</a></li>
            <li class="breadcrumb-item active" aria-current="page">Settings</li>
        </ol>
    </nav>

    <h1 class="mb-4 text-white">Settings</h1>

    @if(session('success'))
        <div class="alert alert-success">
            <ul class="mb-0">
                <li>{{ session('success') }}</li>
            </ul>
        </div>
    @endif

    @if ($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

    <form action="{{ route('updateProfile') }}" method="POST" class="card p-4 shadow-sm border-0 rounded-4">
        @csrf
        @method('PUT')

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control inputTextLong" id="name" name="name" value="{{ $user->name }}" required>
            </div>

            <div class="col-md-6 mb-3">
                <label for="surname" class="form-label">Surname</label>
                <input type="text" class="form-control inputTextLong" id="surname" name="surname" value="{{ $user->surname }}" required>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control inputTextLong" id="username" name="username" value="{{ $user->username }}" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control inputTextLong disabled" id="email" name="email" value="{{ $user->email }}" required disabled>
            </div>

        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="password" class="form-label">New Password (leave blank to keep current)</label>
                <input type="password" class="form-control inputTextLong" id="password" name="password">
            </div>

            <div class="col-md-6 mb-3">
                <label for="password_confirmation" class="form-label">Confirm New Password</label>
                <input type="password" class="form-control inputTextLong" id="password_confirmation" name="password_confirmation">
            </div>
        </div>

        <div class="d-flex justify-content-end mt-3">
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </div>
    </form>
</div>
@endsection

