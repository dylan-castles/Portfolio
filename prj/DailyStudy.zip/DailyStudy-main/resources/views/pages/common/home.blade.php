@extends('layouts.appLayout')

@section('title', 'Home')

@section('content')
<div class="container my-3">

    <h1 class="my-5 text-center text-white">Welcome to DailyStudy</h1>

    <!-- Opciones principales -->
    <div class="row justify-content-center m-4">
        <div class="col-6 col-md-3 mb-3">
            <a href="{{ route('myCoursesPage') }}" class="text-decoration-none">
                <div class="btn btn2 fw-bold w-100 shadow d-flex align-items-center justify-content-center h-100 botonesPrincipalesNavegacion">
                    <strong>My courses</strong>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <a href="{{ route('discoverPage') }}" class="text-decoration-none">
                <div class="btn btn2 fw-bold w-100 shadow d-flex align-items-center justify-content-center h-100 botonesPrincipalesNavegacion">
                    <strong>Discover</strong>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <a href="{{ route('subscriptionProductPage') }}" class="text-decoration-none">
                <div class="btn btn2 fw-bold w-100 shadow d-flex align-items-center justify-content-center h-100 botonesPrincipalesNavegacion">
                    <strong>Our subscriptions</strong>
                </div>
            </a>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <a href="{{ route('myNotesPage') }}" class="text-decoration-none">
                <div class="btn btn2 fw-bold w-100 shadow d-flex align-items-center justify-content-center h-100 botonesPrincipalesNavegacion">
                    <strong>My notes</strong>
                </div>
            </a>
        </div>
    </div>

    {{-- Mis cursos --}}
    @if($coursesOwned->isNotEmpty())
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="textOrange mb-0">Owned Courses</h2>
            <a href="{{ route('myCoursesPage') }}" class="textOrange fw-semibold">
                view all <i class="fas fa-arrow-right ms-1"></i>
            </a>
        </div>
        <div class="row">
            @foreach($coursesOwned as $course)
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <div class="card-body card-body-course">
                            <p class="card-text card-img">
                                <img src="{{ asset('img/coverIMG/cover' . $course->id . '.jpg') }}" class="imgCourse" alt="Course Cover" />
                            </p>
                            <div class="d-flex justify-content-between align-items-start padding-card gap-2 pe-2">
                                <h5 class="card-title mb-0 flex-grow-1 text-truncate" style="max-width: 70%;">{{ $course->title }}</h5>

                                <div class="d-flex align-items-center flex-shrink-0">
                                    <small class="text-muted me-1 favorite-count">{{ $course->users->count() }}</small>
                                    <button class="favorite-btn border-0 bg-transparent p-0" data-course-id="{{ $course->id }}" data-url="{{ route('toggle.favorite') }}">
                                        <svg class="corazon {{ $course->pivot->favorite ? 'active' : '' }}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />

                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <p class="card-text padding-card d-flex justify-content-between">
                                <small class="text-muted">
                                    Status: {{ $course->status_id == 3 || 2 ? 'Not completed' : 'Completed' }}
                                </small>
                            </p>
                        </div>
                        <div class="card-footer">
                            <a href="{{ route('showCourseInfo', ['id' => $course->id]) }}" class="btn btn1 w-100 mx-0">View Course</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif

    {{-- Cursos Populares --}}
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="mb-0 textOrange">Popular Courses</h2>
        <a href="{{ route('discoverPage') }}" class="fw-semibold textOrange">
            view all <i class="fas fa-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="row">
        @foreach($popularCourses as $course)
            <div class="col-md-3 mb-4">
                <div class="card h-100">
                    <div class="card-body card-body-course">
                        <p class="card-text card-img">
                            <img src="{{ asset('img/coverIMG/cover' . $course->id . '.jpg') }}" class="imgCourse" alt="Course Cover" />
                        </p>
                        <div class="d-flex justify-content-between align-items-start padding-card gap-2 pe-2">
                            <h5 class="card-title mb-0 flex-grow-1 text-truncate" style="max-width: 70%;">{{ $course->title }}</h5>

                            <div class="d-flex align-items-center flex-shrink-0">
                                <small class="text-muted me-1 favorite-count">{{ $course->favorites_count }}</small>
                                <button class="favorite-btn border-0 bg-transparent p-0" data-course-id="{{ $course->id }}" data-url="{{ route('toggle.favorite') }}">
                                    <svg class="corazon {{ $course->users->contains(Auth::id()) ? 'active' : '' }}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <p class="card-text padding-card d-flex justify-content-between">

                        </p>
                    </div>
                    <div class="card-footer">
                        <a href="{{ route('showCourseInfo', ['id' => $course->id]) }}" class="btn btn1 w-100 mx-0">View Course</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

@push('scripts')
<script src="{{ asset('js/favorite_button.js') }}"></script>

@endpush

@endsection