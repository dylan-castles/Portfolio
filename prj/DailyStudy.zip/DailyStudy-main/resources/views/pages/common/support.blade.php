@extends('layouts.appLayout')

@section('title', 'Support')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/mainStyles.css') }}">
@endpush

@section('content')
    <div class="container mt-5 d-flex justify-content-center">
        <div class="card shadow-lg w-100" style="max-width: 600px;">
            <div class="card-body">
                <h2 class="card-title text-center fw-bold mb-3">Contact Us</h2>
                <p class="text-center text-muted mb-4">Ask us any questions you may have.</p>

                @if(session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @elseif(session('error'))
                    <div class="alert alert-danger">{{ session('error') }}</div>
                @endif

                <form method="POST" action="{{ route('support.send') }}">
                    @csrf
                    <div class="mb-3">
                        <textarea class="form-control" name="message" rows="6" placeholder="e.g., It won't let me start the course" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Send Message</button>
                </form>
            </div>
        </div>
    </div>
@endsection