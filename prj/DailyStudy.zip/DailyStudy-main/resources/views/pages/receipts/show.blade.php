@extends('layouts.appLayout')

@section('title', 'Receipt #'.$receipt->id)
@section('nav_title', 'Receipt #'.$receipt->id)

@section('content')
<div class="container my-4">

    <!-- Breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">Profile</a></li>
            <li class="breadcrumb-item"><a href="{{ route('myPurchasesPage') }}">My purchases</a></li>
            <li class="breadcrumb-item active" aria-current="page">Receipt #{{ $receipt->id }}</li>
        </ol>
    </nav>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-white mb-0">Receipt #{{ $receipt->id }}</h1>
        <a href="{{ route('myPurchasesPage') }}" class="btn btn3">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
    </div>

    <div class="card bg-light shadow-sm">
        <div class="card-body">
            <h5 class="card-title mb-3">
                <span class="text-muted">Payment Method:</span>
                <span class="text-capitalize fw-semibold">{{ $receipt->payment_method }}</span>
            </h5>

            <h6 class="card-subtitle mb-3 text-muted">
                Purchased on: {{ \Carbon\Carbon::parse($receipt->created_at)->format('d/m/Y H:i') }}
            </h6>

            <table class="table table-sm table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th>Course Title</th>
                        <th>Price Paid</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($receipt->userCourses as $uc)
                        <tr>
                            <td>{{ $uc->course->title }}</td>
                            <td class="text-success fw-bold">{{ number_format($uc->price_paid, 2) }}€</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            @php
                $total = $receipt->userCourses->sum('price_paid');
            @endphp

            <div class="text-end mt-3">
                <span class="fw-bold fs-5">Total: {{ number_format($total, 2) }}€</span>
            </div>
        </div>

        <div class="card-footer text-end">
            <a href="{{ route('downloadReceipt', $receipt->id) }}" class="btn btn2">
                <i class="fas fa-download me-1"></i>Download PDF
            </a>
        </div>
    </div>
</div>
@endsection