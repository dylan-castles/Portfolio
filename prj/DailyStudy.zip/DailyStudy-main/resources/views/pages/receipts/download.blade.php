<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt #{{ $receipt->id }}</title>
    <link rel="stylesheet" href="{{ public_path('css/download.css') }}">
</head>
<body>

    <div class="header">
        <img src="{{ public_path('img/dailyStudyLogo.png') }}" alt="DailyStudy Logo" class="logo">
        <div class="company-info">
            <strong>DailyStudy</strong><br>
            www.dailystudy.com<br>
            support@dailystudy.com
        </div>
    </div>

    <div class="title">Receipt #{{ $receipt->id }}</div>

    <div class="section user-info">
        <strong>Billed To:</strong><br>
        {{ $user->name }} {{ $user->surname }}<br>
        {{ $user->email }}
    </div>

    <div class="section payment-info">
        <p>
            <strong>Payment Method:</strong> <span class="text-capitalize">{{ $receipt->payment_method }}</span><br>
            <strong>Purchase Date:</strong> {{ \Carbon\Carbon::parse($receipt->created_at)->format('d/m/Y H:i') }}
        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Course</th>
                <th style="width: 150px;">Price Paid</th>
            </tr>
        </thead>
        <tbody>
            @foreach($receipt->userCourses as $uc)
                <tr>
                    <td>{{ $uc->course->title }}</td>
                    <td>{{ number_format($uc->price_paid, 2) }}€</td>
                </tr>
            @endforeach
            <tr class="total-row">
                <td style="text-align: right;">Total:</td>
                <td>{{ number_format($receipt->userCourses->sum('price_paid'), 2) }}€</td>
            </tr>
        </tbody>
    </table>

    <p class="thanks">
        Thank you for choosing DailyStudy.<br>
        Keep learning and growing!
    </p>

    <div class="footer">
        This is a digital receipt. No signature required.<br>
        © {{ date('Y') }} DailyStudy. All rights reserved.
    </div>

</body>
</html>
