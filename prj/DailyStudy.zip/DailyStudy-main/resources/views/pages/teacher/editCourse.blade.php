@extends('layouts.appLayout')

@push('styles')
    <link rel="stylesheet" href="{{ asset('css/discover.css') }}">
    <link rel="stylesheet" href="{{ asset('css/teacherDashboard.css') }}">
@endpush

@section('title', 'Edit Course ' . $course->title)

@section('content')
    <div class="container">
        <div class="container my-4">

            <!-- Breadcrumbs -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">Profile</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('teacher.dashboard') }}">Teacher Workspace</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Course {{ $course->title }}</li>
                </ol>
            </nav>

            {{-- Titulo --}}
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center text-white fw-bold">Course Editor</h1>
                    <p class="text-center textOrange">Drop your ideas in this draft</p>
                </div>
            </div>

            {{-- Contenido --}}
            <div class="row">
                <div class="col-12 bg-light p-4 rounded shadow">
                    <form id="editCourseForm" enctype="multipart/form-data">
                        <div class="row g-3 p-3">
                            <!-- Sidebar (izquierda) -->
                            <div class="col-12 col-md-4">
                                <h2 class="text-center fw-bold mb-3">
                                    <i class="fa fa-info-circle text-custom-purple"></i>
                                    Course Information
                                </h2>
                                <!-- Portada del curso -->
                                <div class="mb-4 p-3 bg-white rounded shadow-sm">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-image text-custom-purple me-2"></i>
                                        <label for="cover" class="form-label fw-bold">Course Cover</label>
                                    </div>

                                    @if ($course->id)
                                        <div class="mb-3 text-center">
                                            <small class="text-muted d-block">Current cover</small>
                                            <img src="{{ asset('img/coverIMG/cover' . $course->id . '.jpg') }}"
                                                alt="Current cover"
                                                class="img-fluid rounded shadow-sm border border-2 mb-2">
                                            <small class="text-muted">Recommended: 640x359px </small>
                                        </div>
                                    @endif

                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-upload text-custom-purple"></i>
                                        </span>
                                        <input type="file" class="form-control form-custom-file" id="cover"
                                            name="cover" accept="image/png, image/jpeg, image/jpg, image/webp, image/svg">
                                    </div>

                                    <div class="invalid-feedback"></div>
                                </div>

                                <!-- Categoría -->
                                <div class="mb-4 p-3 bg-white rounded shadow-sm">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-folder-open text-custom-purple me-2"></i>
                                        <label for="courseCategory" class="form-label fw-bold">Category</label>
                                    </div>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-tag text-muted"></i>
                                        </span>
                                        <select class="form-select form-custom-select" id="courseCategory"
                                            name="category_id" required>
                                            <option value="" disabled>Select a category</option>
                                            @foreach ($categoriesWithSubcategories as $category)
                                                <option value="{{ $category->id }}"
                                                    {{ $course->subcategory->category->id == $category->id ? 'selected' : '' }}>
                                                    {{ $category->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="invalid-feedback"></div>
                                </div>

                                <!-- Subcategoría -->
                                <div class="mb-4 p-3 bg-white rounded shadow-sm" id="subcategoryContainer">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-folder text-custom-purple me-2"></i>
                                        <label for="courseSubcategory" class="form-label fw-bold">Subcategory</label>
                                    </div>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="fas fa-tags text-muted"></i>
                                        </span>
                                        <select class="form-select form-custom-select" id="courseSubcategory"
                                            name="subcategory_id" required>
                                            <option value="" disabled>Select a subcategory</option>
                                            @if ($course->subcategory)
                                                @foreach ($categoriesWithSubcategories as $category)
                                                    @if ($category->id == $course->subcategory->category->id)
                                                        @foreach ($category->subcategories as $subcategory)
                                                            <option value="{{ $subcategory->id }}"
                                                                {{ $course->subcategory->id == $subcategory->id ? 'selected' : '' }}>
                                                                {{ $subcategory->name }}</option>
                                                        @endforeach
                                                    @endif
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="invalid-feedback"></div>
                                </div>
                            </div>

                            <!-- Sección principal (derecha)-->
                            <div class="col-12 col-md-8">
                                <!-- Título del curso -->
                                <div class="mb-2 p-3 bg-white rounded shadow-sm">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-heading text-custom-purple me-2"></i>
                                        <label for="courseTitle" class="form-label fw-bold">Course Title</label>
                                    </div>
                                    <input type="text" class="form-control form-custom-input ps-4" id="courseTitle"
                                        name="title" value="{{ $course->title }}" placeholder="Enter course title">
                                    <div class="invalid-feedback"></div>
                                </div>

                                <!-- Descripción del curso -->
                                <div class="mb-2 p-3 bg-white rounded shadow-sm">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-align-left text-custom-purple me-2"></i>
                                        <label for="description" class="form-label fw-bold">Course Description</label>
                                    </div>
                                    <textarea class="form-control form-custom-input ps-4 text-area-custom" id="description" name="description"
                                        rows="19" placeholder="Describe what students will learn">{{ $course->description }}</textarea>
                                    <div class="invalid-feedback"></div>
                                </div>
                            </div>
                        </div>

                        {{-- Sección de capítulos --}}
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-custom-purple text-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h3 class="h5 mb-0">
                                        <i class="fas fa-list-ul me-2"></i>
                                        Course Chapters
                                    </h3>
                                    <button type="button" class="btn btn-sm btn-light rounded-pill shadow-sm"
                                        id="addChapterButton">
                                        <i class="fas fa-plus me-1"></i> Add Chapter
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                @if ($course->chapters && count($course->chapters))
                                    <div class="list-group list-group-flush">
                                        @foreach ($course->chapters as $chapter)
                                            <div class="list-group-item border-0 px-0 py-3">
                                                <div
                                                    class="d-flex flex-column flex-md-row align-items-start align-items-md-center gap-3 border-bottom pb-2">
                                                    <div class="d-flex align-items-center flex-grow-1">
                                                        <span class="badge bg-light text-dark me-3 fw-normal">
                                                            #{{ str_pad($chapter->chapter_number, 2, '0', STR_PAD_LEFT) }}
                                                        </span>
                                                        <div>
                                                            <div class="d-flex align-items-center">
                                                                @if ($chapter->is_exam)
                                                                    <span class="badge bg-danger me-2">Exam</span>
                                                                @endif
                                                                <h6 class="mb-0 fw-semibold">{{ $chapter->title }}</h6>
                                                            </div>
                                                            <small class="text-muted">
                                                                {{ $chapter->is_exam ? 'Test your students knowledge' : 'Educational content' }}
                                                            </small>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex gap-2 mt-2 mt-md-0">
                                                        <a href="{{ route('chapter.edit', ['course' => $course->id, 'chapter' => $chapter->id]) }}"
                                                            class="btn-custom-purple rounded-circle d-flex justify-content-center align-items-center" title="Edit Chapter"
                                                            data-bs-toggle="tooltip">
                                                            <i class="fas fa-pencil-alt"></i>
                                                        </a>
                                                        <button type="button"
                                                            class="btn-custom-red rounded-circle delete-chapter-btn"
                                                            data-chapter-id="{{ $chapter->id }}" title="Delete Chapter"
                                                            data-bs-toggle="tooltip">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                @else
                                    <div class="text-center py-4">
                                        <i class="fas fa-book-open fa-3x text-muted mb-3"></i>
                                        <h5 class="text-muted">No chapters yet</h5>
                                        <p class="text-muted">Start by adding your first chapter</p>
                                    </div>
                                @endif
                            </div>
                        </div>
                </div>
            </div>

            <div class="row g-2 mt-4">
                <div class="col-12 col-md-4">
                    <!-- Delete Course Button triggers modal -->
                    <button type="button" class="btn btn-custom-red w-100 py-2" id="deleteCourseButton"
                        data-bs-toggle="modal" data-bs-target="#deleteCourseModal">
                        <i class="far fa-trash-alt me-2"></i>Delete
                    </button>
                </div>
                <div class="col-12 col-md-4">
                    <button type="button" class="btn btn1 w-100 py-2" id="saveDraftButton">
                        <i class="far fa-save me-2"></i>Save
                    </button>
                </div>
                <div class="col-12 col-md-4">
                    <button type="button" class="btn btn2 w-100 py-2" id="requestPublishButton">
                        <i class="fas fa-paper-plane me-2"></i>Request to publish
                    </button>
                </div>
            </div>
            </form>
        </div>
    </div>
    </div>
    </div>

    <!-- Delete Course Modal (form is inside modal-content, not wrapping modal) -->
    <div class="modal fade" id="deleteCourseModal" tabindex="-1" aria-labelledby="deleteCourseModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" action="{{ route('course.destroy', $course->id) }}">
                    @csrf
                    @method('DELETE')
                    <div class="modal-header text-white bg-gradient-purple">
                        <h5 class="modal-title" id="deleteCourseModalLabel"><i
                                class="fas fa-exclamation-triangle me-2"></i>Confirm Delete</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to delete this course? This action cannot be undone.
                    </div>
                    <div class="modal-footer d-flex justify-content-between">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-outline-danger"
                            id="confirmDeleteCourseBtn">Confirm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    {{-- Pasar las variables de blade a js --}}
    <script>
        window.categoriesWithSubcategories = @json($categoriesWithSubcategories);
        window.course = @json($course);
    </script>

    {{-- Cropper JS --}}
    <script src="https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css" rel="stylesheet" />


    {{-- CDN de chart.js --}}
    <script src="{{ asset('js/utils/utils.js') }}" defer></script>
    <script src="{{ asset('js/teacher/editCourse.js') }}" defer></script>
    <script src="{{ asset('js/teacher/cropCover.js') }}" defer></script>
@endpush
