@extends('layouts.appLayout')

@push('styles')
@endpush

@section('title', 'Course Statistics for ' . $course->title)


@section('content')
    <div class="container-fluid my-4">

        <div class="container">
            <!-- Breadcrumbs -->
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">Profile</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('teacher.dashboard') }}">Teacher Workspace</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Course Statistics for {{ $course->title }} </li>
                </ol>
            </nav>


            {{-- Titulo --}}
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center text-white fw-bold">{{ $course->title }}</h1>
                    <p class="text-center textOrange">View your course statistics</p>
                </div>
            </div>
        </div>

        {{-- Contenido --}}
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div class="card shadow border-0 mb-4">
                    <div class="card-body p-4">
                        <div class="row align-items-center">
                            {{-- Course Image --}}
                            <div class="col-md-4 mb-3 mb-md-0 text-center">
                                <img src="{{ asset('img/coverIMG/cover' . $course->id . '.jpg') }}"
                                    class="img-fluid rounded-3 shadow-sm" alt="{{ $course->title }} Cover Image">
                            </div>
                            <div class="col-md-8">
                                {{-- Course Title & Status --}}
                                <div
                                    class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
                                    <h2 class="fw-bold mb-2 mb-md-0 text-dark">{{ $course->title }}</h2>
                                    <span
                                        class="badge fs-6 bg-{{ $course->status == 'published' ? 'success' : 'secondary' }}">
                                        {{ ucfirst($course->status) }}
                                    </span>
                                </div>

                                {{-- Description --}}
                                <p class="text-muted mb-4">{{ $course->description }}</p>

                                {{-- Grid Info --}}
                                <div class="row g-3">
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="fas fa-tag"></i></span>
                                            <span><strong>Category:</strong>
                                                {{ $course->subcategory->category->name }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="fas fa-tags"></i></span>
                                            <span><strong>Subcategory:</strong> {{ $course->subcategory->name }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="fas fa-user"></i></span>
                                            <span><strong>Owner:</strong> {{ $course->owner->name }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="fas fa-layer-group"></i></span>
                                            <span><strong>Type:</strong> {{ $course->type }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="fas fa-coins"></i></span>
                                            <span><strong>Coins:</strong> {{ $course->coins ?? 'N/A' }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="fas fa-dollar-sign"></i></span>
                                            <span><strong>Price:</strong> {{ $course->price ?? 'N/A' }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="far fa-calendar-plus"></i></span>
                                            <span><strong>Created:</strong>
                                                {{ \Carbon\Carbon::parse($course->created_at)->format('M d, Y') }}</span>
                                        </div>
                                    </div>
                                    <div class="col-6 col-md-6">
                                        <div class="d-flex align-items-center">
                                            <span class="me-2 text-secondary"><i class="far fa-calendar-check"></i></span>
                                            <span><strong>Published:</strong>
                                                {{ \Carbon\Carbon::parse($course->published_date)->format('M d, Y') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Estadisticas --}}
        <div class="container mt-3">
            <div class="row">
                <div class="col-12 mb-4">
                    <h2 class="text-center text-dark fw-bold">Course Statistics</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="card shadow border-0 mb-4">
                        <div class="card-body p-4">
                            <h3 class="text-center text-dark">Students</h3>
                            <canvas id="studentsChart" width="400" height="200"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    {{-- CDN de chart.js --}}
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="{{ asset('js/utils/utils.js') }}" defer></script>
    <script src="{{ asset('js/chart/chartConfig.js') }}"></script>
@endpush
