@extends('layouts.appLayout')

@section('title', 'Review Teacher Requests')

@section('content')
<div class="container mt-5">
    <h1 class="text-white text-center mb-4">Pending Teacher Requests</h1>

    @if($requests->isEmpty())
        <p class="text-white text-center">There are no pending teacher requests.</p>
    @else
        <div class="row justify-content-center">
            @foreach($requests as $user)
                <div class="col-12 col-md-8 col-lg-4 mb-4">
                    <div class="card shadow-lg h-100">
                        <div class="card-body">
                            <h3 class="card-title"><b>{{ $user->name }} {{ $user->surname }}</b></h3>
                            <p class="card-text fw-normal"><strong>Email:</strong> {{ $user->email }}</p>

                            @if ($user->linkedin)
                                <p class="card-text"><strong>LinkedIn:</strong> 
                                    <a href="{{ $user->linkedin }}" target="_blank">View Profile</a>
                                </p>
                            @endif

                            <p><strong>CV:</strong> 
                                <a href="{{ Storage::url($user->cv) }}" target="_blank">View CV</a>
                            </p>

                            <p><strong>Portfolio:</strong> 
                                <a href="{{ Storage::url($user->portfolio) }}" target="_blank">View Portfolio</a>
                            </p>

                            <div class="d-flex flex-column flex-sm-ro mt-4 gap-2">
                                <form action="{{ route('admin.teacher.approve', $user->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-success w-100" style="margin-left: 0px;">Approve</button>
                                </form>

                                <form action="{{ route('admin.teacher.reject', $user->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-danger w-100" style="margin-left: 0px;">Reject</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif
</div>
@endsection