@extends('layouts.appLayout')

@section('title', 'My notes')
@section('nav_title', 'My notes')

@section('content')

<div class="container my-4">

    <!-- Breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">Profile</a></li>
            <li class="breadcrumb-item active" aria-current="page">My notes</li>
        </ol>
    </nav>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-white mb-0">My notes</h1>
        <a href="{{ route('myProfilePage') }}" class="btn btn3">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
    </div>

    <div class="row">

        {{-- Card para crear nueva nota (siempre visible como primero) --}}
        <div class="col-md-4 mb-4">
    <form action="{{ route('note.create') }}" method="POST" id="createNoteForm" class="h-100">
        @csrf
        <div class="card h-100 d-flex justify-content-center align-items-center text-center border-dashed"
            style="border: 2px dashed #ccc; cursor: pointer;"
            onclick="document.getElementById('createNoteForm').submit();">
            <div class="text-decoration-none text-muted d-flex flex-column align-items-center justify-content-center"
                style="height: 100%; padding: 40px 0;">
                <i class="fas fa-plus-circle fa-3x mb-2"></i>
                <span>Crear nueva nota</span>
            </div>
        </div>
    </form>
</div>


        @if($notes->isEmpty())
            <div class="col-md-12">
                <div class="alert alert-info">
                    No tienes notas aún.
                </div>
            </div>
        @else
            @foreach($notes as $note)
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h4 class="card-title">{{ $note->title }}</h4>
                            <p class="card-text">
                                {!! Str::limit(preg_replace('/<img[^>]+\>/i', '', $note->content), 100) !!}
                            </p>
                        </div>
                        <div class="card-footer">
                            <a class="btn btn1" href="{{ route('note.show', $note->id) }}">Ver detalles</a>
                            <form action="{{ route('note.destroy', ['id' => $note->id]) }}" method="POST" class="d-inline delete-note-form">
                                @csrf
                                @method('DELETE')
                                <button type="button" class="btn btn4 show-delete-modal float-end" data-title="{{ $note->title }}">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif

    </div>

<!-- Modal de confirmación de eliminación -->
<div class="modal fade" id="deleteNoteModal" tabindex="-1" aria-labelledby="deleteNoteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteNoteModalLabel">¿Eliminar nota?</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                Estás a punto de eliminar la nota:
                <span class="fw-bold d-block mt-2" id="noteToDeleteTitle"></span>
                <p class="mb-0 mt-2">¿Estás seguro de que deseas continuar?</p>
            </div>
            <div class="modal-footer d-flex justify-content-between">
                <button type="button" class="btn btn1" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn4" id="confirmDeleteBtn">Eliminar</button>
            </div>

        </div>
    </div>
</div>
@push('scripts')
<script>
    let formToDelete = null;

    document.querySelectorAll('.show-delete-modal').forEach(button => {
        button.addEventListener('click', function () {
            formToDelete = this.closest('form');
            const title = this.dataset.title || '';
            document.getElementById('noteToDeleteTitle').textContent = title;
            new bootstrap.Modal(document.getElementById('deleteNoteModal')).show();
        });
    });

    document.getElementById('confirmDeleteBtn').addEventListener('click', function () {
        if (formToDelete) {
            formToDelete.submit();
        }
    });
</script>
@endpush
@endsection
