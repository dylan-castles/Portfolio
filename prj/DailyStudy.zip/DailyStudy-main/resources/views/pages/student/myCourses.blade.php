@extends('layouts.appLayout')

@section('title', 'My courses')
@section('nav_title', 'My courses')

@section('content')
<div class="container my-4">

    <!-- Breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">Profile</a></li>
            <li class="breadcrumb-item active" aria-current="page">My courses</li>
        </ol>
    </nav>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-white mb-0">My courses</h1>
        <a href="{{ route('myProfilePage') }}" class="btn btn3">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
    </div>

    <div class="mb-4">
        <label for="courseStatus" class="form-label text-white fw-bold label-filter">Filter by status:</label>
        <div class="input-group">
            <span class="input-group-text bg-dark text-white"><i class="fas fa-filter"></i></span>
            <select id="courseStatus" class="form-select">
                <option value="all">All courses</option>
                <option value="completed">Completed</option>
                <option value="in_progress">Not completed</option>
            </select>
        </div>
    </div>


    <div id="coursesContainer">
        @if($courses->isEmpty())
            <div class="alert alert-warning text-center shadow-sm" role="alert">
                Not found courses with this status.
            </div>
        @else
            <div class="row">
                @foreach($courses as $course)
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <div class="card-body card-body-course">
                            <p class="card-text card-img">
                                <img src="{{ asset('img/coverIMG/cover' . $course->id . '.jpg') }}" class="imgCourse" alt="Course Cover" />
                            </p>
                            <div class="d-flex justify-content-between align-items-start padding-card gap-2">
                                <h5 class="card-title mb-0 flex-grow-1 text-truncate" style="max-width: 70%;">{{ $course->title }}</h5>

                                <div class="d-flex align-items-center flex-shrink-0">
                                    <small class="text-muted me-1 favorite-count">{{ $course->users->count() }}</small>
                                    <button class="favorite-btn border-0 bg-transparent p-0" data-course-id="{{ $course->id }}" data-url="{{ route('toggle.favorite') }}">
                                        <svg class="corazon {{ $course->pivot->favorite ? 'active' : '' }}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <p class="card-text padding-card d-flex justify-content-between">
                                <small class="text-muted">
                                    Status: {{ $course->status_id == 3 || 2 ? 'Not completed' : 'Completed' }}
                                </small>
                            </p>
                        </div>

                        <div class="card-footer">
                            <a href=" {{route('showCourseInfo',['id' => $course->id]) }}" class="btn btn1 w-100 mx-0">View Course</a>
                        </div>
                    </div>
                </div>
            @endforeach
            </div>
        @endif
    </div>
</div>

@push('scripts')
    <script src="{{ asset('js/courseFilter.js') }}"></script>
    <script src="{{ asset('js/favorite_button.js') }}"></script>
@endpush
@endsection
