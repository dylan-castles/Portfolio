@extends('layouts.appLayout')

@section('title', 'My awards')
@section('nav_title', 'My awards')

@section('content')
<div class="container my-4">
    <!-- Header con botón de back -->

    <!-- Breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('myProfilePage') }}">Profile</a></li>
            <li class="breadcrumb-item active" aria-current="page">My awards</li>
        </ol>
    </nav>



    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-white mb-0">My awards</h1>
        <a href="{{ route('myProfilePage') }}" class="btn btn3">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
    </div>

    <div class="content">
        <H1>COMING SOON...</H1>
    </div>

</div>
@endsection
