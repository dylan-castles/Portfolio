{{-- Formulario de edición de la nota --}}
<form method="POST" id="noteForm" action="{{ route('note.update', $note->id) }}">
    @csrf
    @method('PUT')

    {{-- Campo de título --}}
    <div class="mb-3 text-white">
        <input type="text" id="noteTitle" name="title" class="form-control inputTextLong" value="{{ old('title', $note->title) }}" required>
    </div>

    {{-- Campo de contenido (CKEditor) --}}
    <div class="mb-3">
        <textarea name="content" id="editor1" rows="10" class="form-control">{{ old('content', $note->content) }}</textarea>
    </div>

    <div class="d-flex d-md-block gap-2 mt-4">
        <button type="button" class="btn btn2 flex-fill" id="saveNoteBtn">Guardar Cambios</button>
        <button type="button" class="btn btn1 flex-fill" data-bs-dismiss="modal">Cerrar</button>
    </div>
</form>