<div class="row pb-5">
    <!-- Creación de nueva nota -->
    <div class="col-12 mb-4">
        <form method="POST" id="createNoteForm2" action="/notes/create" class="h-100">
            @csrf
            <div class="card h-100 d-flex justify-content-center align-items-center text-center border-dashed"
                style="border: 2px dashed #ccc; cursor: pointer">
                <div  class="text-decoration-none text-muted d-flex flex-column align-items-center justify-content-center"
                    style="height: 100%; padding: 40px 0;">
                    <i class="fas fa-plus-circle fa-3x mb-2"></i>
                    <span>Crear nueva nota</span>
                </div>
            </div>
        </form>
    </div>

    <!-- Si no hay notas -->
    @if($notes->isEmpty())
        <div class="col-12">
            <div class="alert alert-info">No tienes notas aún.</div>
        </div>
    @else
        <!-- Muestra las notas -->
        @foreach($notes as $note)
            <div class="col-12 mb-4">
                <div class="card h-100">
                    <div class="card-body d-flex flex-column">
                        <h4 class="card-title">{{ $note->title }}</h4>
                        <p class="card-text flex-grow-1">
                            {!! Str::limit(preg_replace('/<img[^>]+\>/i', '', $note->content), 100) !!}
                        </p>
                    </div>
                    <div class="card-footer">
                        <button type="button" class="btn btn1 view-note-details" data-note-id="{{ $note->id }}">Ver detalles</button>
                        <form action="{{ route('note.destroy', ['id' => $note->id]) }}" method="POST" class="d-inline delete-note-form">
                            @csrf
                            @method('DELETE')
                            <button type="button" class="btn btn4 show-delete-modal float-end" data-title="{{ $note->title }}">Eliminar</button>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    @endif

</div>
