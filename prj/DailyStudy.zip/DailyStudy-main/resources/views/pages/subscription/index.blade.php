@extends('layouts.appLayout')

@section('title', 'Subscription Plans')

@section('content')
<div class="container my-4">

    <!-- Breadcrumbs -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('homePage') }}">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Subscription Plans</li>
        </ol>
    </nav>

    <div class="text-center mb-5">
        <h1 class="fw-bold text-white">Choose Your Plan</h1>
        <p class="text-muted">Access premium content with one of our subscription plans.</p>
    </div>

    @if($subscriptions->isEmpty())
        <div class="alert alert-warning text-center">No subscription plans available at the moment.</div>
    @else
        <div class="row justify-content-center">
            @foreach($subscriptions as $subscription)
                <div class="col-md-4 mb-4 d-flex">
                    <div class="card border-0 shadow-lg w-100 d-flex flex-column justify-content-between">
                        <div class="card-body d-flex flex-column text-center" >
                            <h5 class="card-title fw-bold textOrange">{{ $subscription->name }}</h5>
                            <p class="card-text text-muted flex-grow-1">
                                {{ $subscription->description }}
                            </p>
                            @if($subscription->subscription_days === NULL)
                                <p class="text-dark fw-semibold mb-3">
                                    Duration: Forever
                                </p>
                            @else
                                <p class="text-dark fw-semibold mb-3">
                                    Duration: {{ $subscription->subscription_days }} days
                                </p>
                            @endif
                        </div>
                        @if(in_array($subscription->id, $userSubscriptionProductIds))
                            <div class="card-footer bg-transparent border-0 text-center">
                                @if ($subscription->id == 1)
                                    <button class="btn btn2 px-4 py-2 w-75" disabled>
                                        Already subscribed
                                    </button>
                                @else
                                    <button class="btn btn2 px-4 py-2 w-75" disabled>
                                        Already subscribed
                                    </button>
                                    <form action="{{ route('cancelSubscription', ['id' => $subscription->id]) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-danger px-4 py-2 w-75" style="margin-top: 10px;">
                                            Cancel plan
                                        </button>
                                    </form>
                                @endif
                            </div>
                        @else
                            <div class="card-footer bg-transparent border-0 text-center">
                                <form action="{{ route('checkoutSubscription', ['id' => $subscription->id]) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn2 px-4 py-2 w-75">
                                        Buy now for {{ number_format($subscription->price, 2) }}€
                                    </button>
                                </form>
                            </div>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    @endif

</div>
@endsection