@extends('layouts.authLayout')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@section('title', 'Reset password')

@section('content')
    <div class="d-flex justify-content-center align-items-center mb-5" style="min-height: 60vh;">
        <div class="p-5 loginModal" style="width: 100%; max-width: 400px;">
            <!-- Logo centrado con tamaño controlado -->
            <div class="text-center mb-4">
                <a href="{{ route('mainPage') }}">
                    <img src="{{ asset('img/dailyStudyLogo.png') }}" alt="DailyStudy Logo" class="img-fluid" style="max-height: 100px;">
                </a>
            </div>
            <h2 class="text-center mb-4">Reset password</h2>
            <form action="{{ route('auth.restartPassword.submit') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="text" id="email" name="email" class="form-control auth-input" placeholder="Your email" value="{{ old('email') }}">
                </div>
                @error('email')
                    <p class="error" style="color: red;">{{ $message }}</p>
                @enderror
                <div class="d-grid d-flex justify-content-center mb-3">
                    <button type="submit" class="btn btn1">Send</button>
                </div>
            </form>
            <p class="pt-2 mb-0">Don't have an account? Register <a href="{{ route('registerPage') }}">here</a></p>

        </div>
    </div>
@endsection

@section('scripts')
    <script src="{{ asset('js/reset_password.js') }}"></script>

    @if(session('success'))
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: "{{ session('success') }}",
                confirmButtonColor: '#6f42c1'
            });
        </script>
    @endif
@endsection