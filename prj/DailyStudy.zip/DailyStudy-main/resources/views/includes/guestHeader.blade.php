<header class="headerMainClass text-white py-3">
    <nav class="d-flex justify-content-between align-items-center w-100 h-100">

        {{-- Logo + Saludo --}}
        <div class="d-flex align-items-center gap-3">
            @if (auth()->check())
                <a href="{{ route('homePage') }}" class="d-inline-block h-100" title="Home">
                    <img src="{{ asset('img/dailyStudyLogo.png') }}" alt="DailyStudy Logo" class="img-fluid"
                        style="height: 50px;">
                </a>
            @else
                <a href="{{ route('mainPage') }}" class="d-inline-block h-100" title="Home">
                    <img src="{{ asset('img/dailyStudyLogo.png') }}" alt="DailyStudy Logo" class="img-fluid"
                        style="height: 50px;">
                </a>
            @endif
        </div>

        {{-- Botones de acción y perfil --}}
        <div class="d-flex align-items-center gap-2">
            <a href="{{ route('login') }}"
                class="btn btn1 d-flex align-items-center justify-content-center btnHeader" title="My cart">
                <i class="fa-solid fa-right-to-bracket fs-6 me-1"></i>
                <span class="d-none d-md-inline">Log In</span>
            </a>
            <a href="{{ route('registerPage') }}"
                class="btn btn2 d-flex align-items-center justify-content-center btnHeader" title="My cart">
                <i class="fa-regular fa-address-card fs-6 me-1"></i>
                <span class="d-none d-md-inline">Register</span>
            </a>
        </div>
    </nav>
</header>
