<footer class="text-white pt-5 pb-3 mt-auto">
    <div class="container">
        <div class="row">

            <!-- About Us -->
            <div class="col-md-3 mb-4 mb-md-0">
                <h5 class="text-uppercase">About Us</h5>
                <p>
                    We are a team dedicated to connecting knowledge with opportunity.
                    Our mission is to bring quality learning experiences to everyone.
                </p>
            </div>

            <!-- Quick Links -->
            <div class="col-md-3 mb-4 mb-md-0">
                <h5 class="text-uppercase">Quick Links</h5>
                <ul class="list-unstyled">
                    @if (auth()->check())
                        <li><a href="{{route('homePage')}}" class="text-white text-decoration-none">Home</a></li>
                    @else
                        <li><a href="{{route('mainPage')}}" class="text-white text-decoration-none">Home</a></li>
                    @endif
                    <li><a href="{{route('faqPage')}}" class="text-white text-decoration-none">FAQ</a></li>
                    <li><a href="{{route('support')}}" class="text-white text-decoration-none">Support</a></li>
                    @if (auth()->check())
                        <li><a href="{{route('teacher.request')}}" class="text-white text-decoration-none">I am a teacher</a></li>
                    @endif
                </ul>
            </div>

            <!-- Contact Info -->
            <div class="col-md-3 mb-4 mb-md-0">
                <h5 class="text-uppercase">Contact Us</h5>
                <ul class="list-unstyled">
                    <li><i class="fa-solid fa-envelope me-2"></i> info.dailystudy@gmail.com</li>
                    <li><i class="fa-solid fa-phone me-2"></i> +34 685 416 098</li>
                </ul>
            </div>

            <!-- Social Media -->
            <div class="col-md-3">
                <h5 class="text-uppercase">Follow Us</h5>
                <div>
                    <a href="https://facebook.com/profile.php?id=61576385912688" class="text-white me-2"><i class="fa-brands fa-facebook-f fa-lg"></i></a>
                    <a href="https://x.com/DailyStudy25" class="text-white me-2"><i class="fa-brands fa-x-twitter fa-lg"></i></a>
                    <a href="https://www.instagram.com/dailystudy_es/" class="text-white me-2"><i class="fa-brands fa-instagram fa-lg"></i></a>
                </div>
            </div>

        </div>
        <hr class="bg-white my-4">
        <div class="row">
            <div class="col text-center">
                <p class="mb-0">&copy; 2025 DailyStudy. All rights reserved.</p>
                <small class="d-block">Designed by DailyStudy Team</small>
                <small class="d-block">Version V6</small>
            </div>
        </div>
    </div>
</footer>