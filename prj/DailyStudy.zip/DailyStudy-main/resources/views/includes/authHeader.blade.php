<header>
    
    <div class="py-3 headerMainClass">
        <div class="d-flex justify-content-between align-items-center w-100 h-100">
            <div class="h-100">
                <a href="{{ route('mainPage') }}">
                    <img class="h-100" src="{{ asset('img/dailyStudyLogo.png') }}" alt="DailyStudy Logo">
                </a>
            </div>
            @if (Route::currentRouteName() === 'login')
                <div class="contenedorBotonesHeader">
                    <a href="{{route('registerPage')}}" class="btn btn1 btn-header"><i class="fa-solid fa-user-plus me-2"></i>Register</a>
                </div>
            @elseif (Route::currentRouteName() === 'registerPage' || Route::currentRouteName() === 'resetPasswordForm')
                <div class="contenedorBotonesHeader">
                    <a href="{{route('login')}}" class="btn btn2 btn-header"><i class="fa-solid fa-key me-2"></i> Login</a>
                </div>
            @endif
        </div>
    </div>
</header>