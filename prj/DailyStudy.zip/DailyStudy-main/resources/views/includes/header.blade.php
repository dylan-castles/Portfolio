<header>
  <div class="header1 hide">
      <div class="py-2 h-100 d-flex align-items-center" style="background-color: #561eaa; color: white;">
        <div class="container">
          <div class="d-flex justify-content-between align-items-center flex-wrap ">
            <!-- Grupo Izquierdo: Información de Contacto -->
            <div class="d-flex align-items-center">
              <small>Call us: +34 685 416 098</small>
              <span class="mx-2">|</span>
              <small>Email: info.dailystudy@gmail.com</small>
            </div>
            <!-- Grupo Derecho: Redes, FAQ, Support, Idioma, Cuenta y Carrito -->
            <div class="d-flex align-items-center">
              <a href="https://facebook.com/profile.php?id=61576385912688" class="text-white me-2"><i class="fa-brands fa-facebook-f"></i></a>
              <a href="https://x.com/DailyStudy25" class="text-white me-2"><i class="fa-brands fa-x-twitter"></i></a>
              <a href="https://www.instagram.com/dailystudy_es/" class="text-white me-2"><i class="fa-brands fa-instagram"></i></a>
              <span class="text-white mx-2">|</span>
              <a href="{{route('faqPage')}}" class="text-white me-2">FAQ</a>
              <a href="{{route('support')}}" class="text-white me-2">Support</a>
              <span class="text-white mx-2">|</span>
              <a href="{{route('myProfilePage')}}" class="text-white me-3">My Account</a>
            </div>
          </div>
        </div>
      </div>
  </div>


      {{-- HEADER --}}
    @if(Auth::check())
        @include('includes.clientHeader')
    @else
        @include('includes.guestHeader')
    @endif

</header>