function setUpCategoryAndSubcategorySelects() {
    const selectCategory = document.getElementById("courseCategory");
    const containerSubcategory = document.getElementById(
        "subcategoryContainer"
    );
    const selectSubcategory = document.getElementById("courseSubcategory");

    if (!selectCategory || !containerSubcategory || !selectSubcategory) return;

    selectCategory.addEventListener("change", function () {
        const selectedCategoryId = selectCategory.value;

        // Mostrar el contenedor de subcategorías
        containerSubcategory.classList.remove("d-none");
        containerSubcategory.classList.add("d-block");

        // Limpiar subcategorías anteriores
        selectSubcategory.innerHTML =
            '<option value="" disabled selected>Select a subcategory</option>';

        // Buscar la categoría seleccionada en el array JS
        const category = window.categoriesWithSubcategories.find(
            (cat) => cat.id == selectedCategoryId
        );

        // Si la categoría tiene subcategorías, añadirlas al select
        if (category && Array.isArray(category.subcategories)) {
            // Añadir las subcategorías al select
            category.subcategories.forEach((subcat) => {
                const option = document.createElement("option");
                option.value = subcat.id;
                option.textContent = subcat.name;
                selectSubcategory.appendChild(option);
            });
        }
    });
}

// Funciones notificación usando Notyf
const notyf = new Notyf({
    duration: 3000,
    position: { x: 'right', y: 'top' },
    ripple: true,
    types: [
        {
            type: 'success',
            background: '#FF7300',
            icon: false,
        },
        {
            type: 'error',
            background: '#e74c3c',
            icon: false,
        },
    ],
});

// Función para notificación de éxito
function notifySuccess(message) {
    notyf.open({
        type: 'success',
        message: message
    });
}

// Función para notificación de error
function notifyError(message) {
    notyf.open({
        type: 'error',
        message: message
    });
}

// Función para mostrar un modal de confirmación
function showConfirmationModal(title, text, confirmCallback) {
    Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e74c3c',
        cancelButtonColor: '#561eaa',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            confirmCallback();
        }
    });
}