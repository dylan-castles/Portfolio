document.addEventListener('DOMContentLoaded', () => {
    const toggleProgressBtn = document.getElementById('progressSideBarBTN');
    if (toggleProgressBtn) {
        toggleProgressBtn.addEventListener('click', function() {
            const progressContainer = document.getElementById('progressContainer');
            // Alternar la clase 'active' para abrir/cerrar la barra lateral
            progressContainer.classList.toggle('active');
        });
    }

    const closeProgressBtn = document.getElementById('closeProgressSidebar'); // Corregir el ID aquí
    if (closeProgressBtn) {
        closeProgressBtn.addEventListener('click', function() {
            const progressContainer = document.getElementById('progressContainer');
            // Eliminar la clase 'active' para cerrar la barra lateral
            progressContainer.classList.remove('active');
        });
    }
});
