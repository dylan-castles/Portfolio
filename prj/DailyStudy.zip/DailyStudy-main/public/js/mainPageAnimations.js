document.addEventListener('DOMContentLoaded', function() {
    // Si ya aceptó, no mostramos
    if (localStorage.getItem('cookieConsent')) return;

    const banner = document.getElementById('cookie-banner');
    banner.classList.remove('d-none');

    document.getElementById('accept-cookies').addEventListener('click', function() {
      // Ocultar banner y guardar consentimiento
      banner.remove();
      localStorage.setItem('cookieConsent', 'true');
    });
  });

  document.addEventListener('DOMContentLoaded', function() {
    // No mostrar si ya lo hemos enseñado
    if (localStorage.getItem('registerPromptShown')) return;
  
    let triggered = false;
    const overlay = document.getElementById('register-overlay');
    const popup   = document.getElementById('register-popup');
    const btnClose = document.getElementById('register-close-btn');
    const btnNow   = document.getElementById('register-now-btn');
  
    function showRegisterPopup() {
      // Marcar para no volver a mostrar
      localStorage.setItem('registerPromptShown', 'true');
      // Volver al top suavemente
      window.scrollTo({ top: 0, behavior: 'smooth' });
      // Mostrar overlay y popup
      overlay.style.display = 'block';
      popup.style.display   = 'block';
      // Enfocar botón de registro
      btnNow.focus();
    }
  
    // Cerrar popup
    btnClose.addEventListener('click', ()=> {
      overlay.style.display = 'none';
      popup.style.display   = 'none';
    });
  
    // Detectar scroll a fondo
    window.addEventListener('scroll', () => {
      if (triggered) return;
      if (window.innerHeight + window.scrollY >= document.body.scrollHeight - 2) {
        triggered = true;
        showRegisterPopup();
      }
    });
  });
