// Función de entrada
function init() {
    // Obtenemos el objeto del curso
    const course = getCourse();

    if (!course) {
        console.error("Course object not found.");
        return;
    }

    // Recuperamos la categoría y subcategoría del curso
    const courseCategoryID = course.subcategory.category.id;
    const courseSubcategoryID = course.subcategory.id;

    // Inicializa los selects de categoría y subcategoría
    setUpCategoryAndSubcategorySelects(courseCategoryID, courseSubcategoryID);

    // Inicializamos el botón de addChapter
    const addChapterButton = document.getElementById("addChapterButton");
    
    // Añadimos el evento al botón de añadir capítulo
    if (addChapterButton) {
        addChapterButton.addEventListener("click", () => { addChapter(course.id) });
    }

    // Añadimos el evento a todos los botones de eliminar capítulo
    const deleteChapterButtons = document.querySelectorAll(".delete-chapter-btn");
    if (deleteChapterButtons.length > 0) {
        deleteChapterButtons.forEach((button) => {
            button.addEventListener("click", (event) => {
                event.preventDefault();
                const chapterId = button.dataset.chapterId;
                deleteChapter(chapterId);
            });
        });
    }

    // Inizializamos el botón editar
    const editButton = document.getElementById("saveDraftButton");

    if (editButton) {
        editButton.addEventListener("click", (event) => {
            event.preventDefault();
            if (validateEditCourseForm()) {
                updateCourse(course.id);

                // Notificamos al usuario que el curso se ha guardado
                notifySuccess("Course saved successfully.");
            }
        });
    }

    // Inicializamos el botón de request to publish
    const requestToPublishButton = document.getElementById("requestPublishButton");

    if (requestToPublishButton) {
        requestToPublishButton.addEventListener("click", (event) => {
            event.preventDefault();
            if (validateEditCourseForm()) {
                let updateCourseStatus = 'review'
                updateCourse(course.id, updateCourseStatus);
                notifySuccess("Course status updated to 'review'. Waiting for approval.");
                window.location.reload(); // recargamos la página (Redirigirá a teacher dashboard porque el estado del curso ha cambiado)
            }
        });
    }
}

// Función para actualizar el curso
function updateCourse(courseId, updateCourseStatus = 'draft') {
    const form = document.getElementById("editCourseForm");
    const formData = new FormData(form);

    if (!courseId) {
        console.error("Course ID is missing.");
        return;
    }

    // Spoof method PUT para Laravel
    formData.append('_method', 'PUT');
    formData.append('course_id', courseId);

    // Añadimos el estado del curso
    formData.append('status', updateCourseStatus);

    fetch(`/api/course/update`, {
        method: 'POST', // Usamos POST, pero Laravel lo tratará como PUT
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name=\"csrf-token\"]').getAttribute('content')
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            return;
        })
        .catch(error => {
            console.error('Error updating course:', error);
            notifyError("Error updating course: " + error.message);
        });
}

// Función para añadir un capítulo
function addChapter(courseId) {
    // Obtenemos el número de capítulo siguiente
    if (!courseId) {
        console.error("Course ID or next chapter number is missing.");
        return;
    }

    // Creamos un nuevo capítulo
    const newChapter = {
        course_id: courseId,
    };

    // Enviamos el nuevo capítulo al servidor
    fetch('/api/chapter/store', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        },
        body: JSON.stringify(newChapter)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            window.location.reload();
        })
        .catch(error => {
            console.error('Error adding chapter:', error);
        });

    return;
}

// Función para eliminar un capítulo
function deleteChapter(chapterId) {
    if (!chapterId) {
        console.error("Chapter ID is missing.");
        return;
    }

    // Mostramos un modal de confirmación antes de eliminar (utils.js)
    showConfirmationModal(
        'Are you sure?',
        "You won't be able to revert this!",
        function() {
            fetch(`/api/chapter/destroy`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ id: chapterId })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                window.location.reload();
            })
            .catch(error => {
                console.error('Error deleting chapter:', error);
                notifyError('Error deleting chapter: ' + error.message);
            });
        }
    );
}

// Función para obtener el objeto del curso
function getCourse() {
    const course = window.course;
    return course;
}

// Valida el formulario de edición de curso. Devuelve true si es válido, false si no.
function validateEditCourseForm() {
    const form = document.getElementById('editCourseForm');
    let isValid = true;

    // Campos obligatorios (menos la imagen)
    const requiredFields = [
        { id: 'courseTitle', msg: 'Title is required.' },
        { id: 'description', msg: 'Description is required.' },
        { id: 'courseCategory', msg: 'Category is required.' },
        { id: 'courseSubcategory', msg: 'Subcategory is required.' }
    ];

    requiredFields.forEach(field => {
        const input = document.getElementById(field.id);
        const feedback = input ? input.closest('.mb-4, .mb-2, .p-3').querySelector('.invalid-feedback') : null;
        if (input && (input.value === '' || input.value === null)) {
            input.classList.add('is-invalid');
            if (feedback) feedback.textContent = field.msg;
            isValid = false;
        } else if (input) {
            input.classList.remove('is-invalid');
            if (feedback) feedback.textContent = '';
        }
    });

    return isValid;
}

document.addEventListener("DOMContentLoaded", init);