<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCourseStatus extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'user_course_statuses';

    // Atributos asignables masivamente
    protected $fillable = [
        'name',
    ];

    /**
     * Relación: Un estado de curso tiene muchos registros en user_courses.
     */
    public function userCourses()
    {
        return $this->hasMany(UserCourse::class, 'status_id');
    }
}
