<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Forum extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'forums';

    // Deshabilitamos los timestamps ya que la migración no define 'created_at' ni 'updated_at'
    public $timestamps = true;

    // Atributos asignables masivamente
    protected $fillable = [
        'title', // Título del foro
        'course_id', // FK al curso al que pertenece el foro
    ];

    /**
     * Relación con el modelo Course.
     * Un foro pertenece a un curso.
     */

    public function course()
    {
        return $this->belongsTo(Course::class, 'course_id');
    }

    /**
     * Relación con el modelo Message.
     * Un foro tiene muchos mensajes.
     */
    public function messages()
    {
        return $this->hasMany(Message::class, 'forum_id');
    }
}
