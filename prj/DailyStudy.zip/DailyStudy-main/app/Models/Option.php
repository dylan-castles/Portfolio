<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Option extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'options';

    // Deshabilitamos los timestamps ya que la migración no define 'created_at' ni 'updated_at'
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'exercise_id',
        'answer',
        'is_correct'
    ];

    /**
     * Relación: Una opción pertenece a un ejercicio.
     */
    public function exercise()
    {
        return $this->belongsTo(Exercise::class, 'exercise_id');
    }
}
