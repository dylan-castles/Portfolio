<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla para evitar ambigüedades.
    protected $table = 'exercises';

    // Deshabilitamos los timestamps, ya que la migración no define 'created_at' ni 'updated_at'.
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'exercise_number',
        'title',
        'content',
        'chapter_id',
        'type'
    ];

    // Castings para convertir el campo exercise_number a entero.
    protected $casts = [
        'exercise_number' => 'integer',
    ];

    /**
     * Relación: Un ejercicio pertenece a un capítulo.
     */
    public function chapter()
    {
        return $this->belongsTo(Chapter::class, 'chapter_id');
    }
    
    // Relación con las opciones
    public function options()
    {
        return $this->hasMany(Option::class, 'exercise_id');
    }

    // Relación con progresos
    public function progresses()
    {
        return $this->hasMany(Progress::class, 'exercise_id');
    }
}
