<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Models\Role;
use App\Models\Course;
use App\Models\UserCourse;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    // Especificamos los atributos que se pueden asignar de forma masiva.
    protected $fillable = [
        'name',
        'surname',
        'username',
        'email',
        'password',
        'coins',
        'status',
        'completed_courses',
        'role_id',
        'external_id',
        'external_auth',
        'change_role',
        'cv',
        'portfolio',
        'linkedin',
        'remember_token',
    ];

    // Atributos ocultos en la serialización
    protected $hidden = [
        'password',
        'remember_token',
    ];

    // Definimos los castings para convertir el tipo de dato cuando se recuperan del modelo.
    protected $casts = [
        // 'email_verified_at'  => 'datetime',
        'password'           => 'hashed',
        'coins'              => 'integer',
        'completed_courses'  => 'integer',
    ];

    /**
     * Relación: Un usuario pertenece a un rol.
     */
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    // Relación 1:N con la tabla notes
    public function notes()
    {
        return $this->hasMany(Note::class, 'owner_id');
    }


    public function userCourses()
    {
        return $this->hasMany(UserCourse::class, 'user_id');
    }

    //Relación N:M con cursos a través de la tabla user_courses
    public function courses()
    {
        return $this->belongsToMany(Course::class, 'user_courses', 'user_id', 'course_id')->withPivot('status_id', 'receipt_id', 'price_paid', 'favorite')->withTimestamps();
    }

    //Cursos comprados por el usuario
    public function ownedCourses(){
        return $this->belongsToMany(Course::class, 'user_courses', 'user_id', 'course_id')->withPivot('status_id', 'receipt_id', 'price_paid')->wherePivot('status_id', 2); // Asumiendo que 2 = completado
    }

    // Relación 1:N con la tabla progresses
    public function progresses()
    {
        return $this->hasMany(Progress::class, 'user_id');
    }

    // Relacion 1:N con la tabla subscriptions
    public function subscriptions()
    {
        return $this->hasMany(Subscription::class, 'user_id');
    }

    // Relación de un usuario propietario de varios cursos
    public function coursesIsOwner()
    {
        return $this->hasMany(Course::class, 'owner_id');
    }

    // Relación 1:N con la tabla messages
    public function messages()
    {
        return $this->hasMany(Message::class, 'user_id');
    }
}