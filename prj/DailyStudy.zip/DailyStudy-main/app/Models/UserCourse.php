<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCourse extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'user_courses';

    // Atributos asignables masivamente
    protected $fillable = [
        'user_id',
        'course_id',
        'status_id',
        'receipt_id',
        'favorite',
        'price_paid',
        'rating',
        'favorite'
    ];

    /**
     * Relación: Un registro en user_courses pertenece a un usuario.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Relación: Un registro en user_courses pertenece a un curso.
     */
    public function course()
    {
        return $this->belongsTo(Course::class, 'course_id');
    }

    /**
     * Relación: Un registro en user_courses pertenece a un estado de curso.
     */
    public function status()
    {
        return $this->belongsTo(UserCourseStatus::class, 'status_id');
    }

    /**
     * Relación: Un registro en user_courses puede estar asociado a un recibo.
     */
    public function receipt()
    {
        return $this->belongsTo(Receipt::class, 'receipt_id');
    }

    // Relación con certificados
    public function certificates()
    {
        return $this->hasMany(UserCertificate::class, 'user_course_id');
    }
}