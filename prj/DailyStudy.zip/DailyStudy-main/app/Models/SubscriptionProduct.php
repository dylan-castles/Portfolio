<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SubscriptionProduct extends Model
{
    use HasFactory;

    // Nombre explícito de la tabla
    protected $table = 'subscription_products';

    // La tabla no tiene created_at ni updated_at
    public $timestamps = false;

    // Campos asignables masivamente
    protected $fillable = [
        'name',
        'description',
        'price',
        'subscription_days',
    ];

    /**
     * Relación: un producto de suscripción puede estar asociado a muchas suscripciones.
     */
    public function subscriptions()
    {
        return $this->hasMany(Subscription::class, 'subscription_product_id');
    }
}