<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Progress extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'progresses';

    // Deshabilitamos los timestamps, ya que la migración no define 'created_at' ni 'updated_at'
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'exercise_id',
        'user_id',
        'status'
    ];

    /**
     * Relación: Un progreso pertenece a un ejercicio.
     */
    public function exercise()
    {
        return $this->belongsTo(Exercise::class, 'exercise_id');
    }

    /**
     * Relación: Un progreso pertenece a un usuario.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
