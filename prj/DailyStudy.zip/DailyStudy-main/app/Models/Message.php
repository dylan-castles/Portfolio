<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Message extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'messages';

    // Deshabilitamos los timestamps ya que la migración no define 'created_at' ni 'updated_at'
    public $timestamps = true;

    // Atributos asignables masivamente
    protected $fillable = [
        'title', // Título del foro
        'user_id', // FK al usuario al
        'content', // Contenido del mensaje
        'forum_id', // FK al foro al que pertenece el mensaje
    ];


    /**
     * Relación con el modelo Forum.
     * Un mensaje pertenece a un foro.
     */
    public function forum()
    {
        return $this->belongsTo(Forum::class, 'forum_id');
    }

    /**
     * Relación con el modelo User.
     * Un mensaje pertenece a un usuario.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
