<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'categories';

    // Deshabilitamos los timestamps, ya que en la migración no se definieron columnas para created_at ni updated_at
    public $timestamps = false;

    // Definimos los atributos asignables masivamente
    protected $fillable = ['name', 'description'];

    // Relación: Una categoría tiene muchas subcategorías
    public function subcategories()
    {
        return $this->hasMany(Subcategory::class, 'category_id');
    }
}
