<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subcategory extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'subcategories';

    // Dado que la migración no incluye timestamps, se deshabilitan.
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'name',
        'description',
        'category_id',
    ];

    /**
     * Relación: Una subcategoría pertenece a una categoría.
     */
    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
}
