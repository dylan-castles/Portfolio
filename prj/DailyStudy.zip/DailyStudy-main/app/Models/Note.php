<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'notes';

    // Deshabilitamos los timestamps, ya que la migración no incluye 'created_at' ni 'updated_at'
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'title',
        'content',
        'owner_id'
    ];

    /**
     * Relación: Una nota pertenece a un usuario (propietario).
     */
    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }
}