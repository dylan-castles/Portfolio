<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCertificate extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'user_certificates';

    // Deshabilitamos los timestamps automáticos ya que la migración solo define 'created_at'
    public $timestamps = false;

    // Definimos los atributos asignables masivamente
    protected $fillable = [
        'user_course_id',
        'created_at',
        'verification_code',
    ];

    // Castings para los atributos
    protected $casts = [
        'created_at'        => 'datetime',
        'verification_code' => 'integer',
    ];

    /**
     * Relación: Un certificado pertenece a un registro de curso del usuario.
     */
    public function userCourse()
    {
        return $this->belongsTo(UserCourse::class, 'user_course_id');
    }
}