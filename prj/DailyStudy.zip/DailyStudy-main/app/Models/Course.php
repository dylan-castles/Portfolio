<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'courses';

    // Dado que la migración no define created_at ni updated_at, deshabilitamos los timestamps
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'title',
        'description',
        'cover',
        'price',
        'coins',
        'type',
        'owner_id',
        'subcategory_id',
        'published_date'
    ];

    // Castings para algunos atributos:
    // - 'price' se castea a decimal con 2 decimales
    // - 'coins' a entero
    // - 'published_date' a datetime
    protected $casts = [
        'price' => 'decimal:2',
        'coins' => 'integer',
        'published_date' => 'datetime',
    ];

    /**
     * Relación: Un curso pertenece a un usuario (propietario) que se encuentra en la columna owner_id.
     */
    public function owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    /**
     * Relación: Un curso pertenece a una subcategoría.
     */
    public function subcategory()
    {
        return $this->belongsTo(Subcategory::class, 'subcategory_id');
    }

    /**
     * Relación: Un curso tiene muchos capítulos.
     */
    public function chapters()
    {
        return $this->hasMany(Chapter::class, 'course_id');
    }

    /**
     * Relación: Un curso tiene una relación N:M a usuarios a través de la tabla user_courses.
     * Esta relación se define en el modelo UserCourse.
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'user_courses', 'course_id', 'user_id')->withPivot('status_id', 'receipt_id', 'price_paid')->withTimestamps();
    }

    /**
     * Relación: Un curso tiene un foro.
     */
    public function forum()
    {
        return $this->hasOne(Forum::class, 'course_id');
    }
}
