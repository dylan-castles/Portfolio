<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Receipt extends Model
{
    use HasFactory;

    // Definimos explícitamente la tabla para evitar ambigüedades
    protected $table = 'receipts';

    // Deshabilitamos los timestamps automáticos, ya que solo contamos con `created_at`
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = ['payment_method', 'session_id', 'created_at'];

        /**
     * Relación: Un recibo puede estar asociado a muchos registros de user_courses.
     */
    public function userCourses()
    {
        return $this->hasMany(UserCourse::class, 'receipt_id');
    }
}
