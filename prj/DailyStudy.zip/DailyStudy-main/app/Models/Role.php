<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Role extends Model
{
    use HasFactory;

    // Especificamos explícitamente la tabla asociada para evitar ambigüedades
    protected $table = 'roles';

    // Dado que la migración no incluye timestamps, deshabilitamos su uso
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = ['name'];

    /**
     * Relación: Un rol puede tener muchos usuarios.
     */
    public function users()
    {
        return $this->hasMany(User::class, 'role_id');
    }
}