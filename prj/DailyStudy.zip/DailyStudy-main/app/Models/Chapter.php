<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chapter extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'chapters';

    // Deshabilitamos los timestamps ya que la migración no define 'created_at' ni 'updated_at'
    public $timestamps = false;

    // Atributos asignables masivamente
    protected $fillable = [
        'chapter_number',
        'title',
        'description',
        'content',
        'course_id',
        'is_exam'
    ];

    // Castings para convertir tipos de datos
    protected $casts = [
        'chapter_number' => 'integer',
        'is_exam'        => 'boolean',
    ];

    /**
     * Relación: Un capítulo pertenece a un curso.
     */
    public function course()
    {
        return $this->belongsTo(Course::class, 'course_id');
    }

    /**
     * Relación: Un capítulo puede tener muchos ejericicos.
     */
    public function exercises()
    {
        return $this->hasMany(Exercise::class, 'chapter_id');
    }

    // Método que recupera sin un capítulo específico es un examen
    public function isExam()
    {
        return $this->is_exam;
    }
}