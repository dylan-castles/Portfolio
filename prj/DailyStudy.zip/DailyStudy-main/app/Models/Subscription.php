<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;

    // Especificamos explícitamente el nombre de la tabla
    protected $table = 'subscriptions';

    // Atributos asignables masivamente
    protected $fillable = [
        'user_id',
        'subscription_product_id',
        'price_paid',
        'subscription_date',
        'receipt_id'
    ];

    /**
     * Relación: Una suscripción pertenece a un usuario.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Relación: Una suscripción pertenece a un producto de suscripción.
     */
    public function subscriptionProduct()
    {
        return $this->belongsTo(SubscriptionProduct::class, 'subscription_product_id');
    }

    /**
     * Relación: Una suscripción pertenece a un recibo.
     */
    public function receipt()
    {
        return $this->belongsTo(Receipt::class, 'receipt_id');
    }
}