<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class RoleMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|string[]  $roles
     * @return mixed
     */
    
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        // Obtener el usuario autenticado
        $user = Auth::user();
        
        // dd($user);

        // Verificar si el usuario tiene uno de los roles permitidos
        if (!$user->role || !in_array($user->role->name, $roles)) {
            return redirect('login');
        }

        // Si el usuario tiene el rol adecuado, continuar con la solicitud
        return $next($request);
    }
}
