<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Http\Controllers\CategoryController;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    // Método que devuelve la vista de discover
    public function discover()
    {
        // Recuperar categorías y subcategorías
        $categoriesWithSubcategories = CategoryController::getCategoriesWithSubcategories();

        // dd($courses->toArray());

        // Renderizar la vista de discover con las variables necesarias
        return view('pages.common.discover', compact('categoriesWithSubcategories'));
    }
}
