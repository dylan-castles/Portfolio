<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserCourse;
use App\Http\Controllers\CategoryController;

class TeacherController extends Controller
{
    // Método para mostrar el workspace del profesor
    public function dashboard()
    {
        $courses = auth()->user()->coursesIsOwner()
            ->select('id', 'title', 'description', 'price', 'coins', 'type', 'status', 'owner_id', 'subcategory_id', 'published_date')
            ->with('subcategory:id,name')
            ->with('owner:id,name')
            ->with('subcategory.category:id,name')
            ->orderBy('id', 'desc')
            ->paginate(7); // 7 cursos por página

        // Variable auxiliar para el estado del curso renderizado en la vista
        $courseStates = [
            'published' => [
                'badge' => 'bg-primary',
                'icon' => 'fas fa-check-circle',
                'button_class' => 'btn btn1 w-100 m-0',
                'button_icon' => 'fas fa-chart-bar',
                'button_title' => 'Stats',
                'link' => "course.stats",
            ],
            'draft' => [
                'badge' => 'bg-secondary',
                'icon' => 'fas fa-pencil-alt',
                'button_class' => 'btn btn2 w-100 m-0',
                'button_icon' => 'fas fa-pencil-alt',
                'button_title' => 'Edit',
                'link' => 'course.edit.view',
            ],
            'review' => [
                'badge' => 'bg-info',
                'icon' => 'fas fa-clock',
                'button_class' => 'btn btn3 w-100 m-0',
                'button_icon' => 'fas fa-clock',
                'button_title' => 'Review',
                'link' => '#',
            ],
            'unpublished' => [
                'badge' => 'bg-danger',
                'icon' => 'fas fa-eye-slash',
                'button_class' => 'btn btn4 w-100 m-0',
                'button_icon' => 'fas fa-eye',
                'button_title' => 'Request to publish',
                'link' => '#',
            ],
        ];

        // Recuperamos las categorías y subcategorías
        $categoriesWithSubcategories = CategoryController::getCategoriesWithSubcategories();


        // dd($categoriesWithSubcategories->toArray());

        return view('pages.teacher.dashboard', compact('courses', 'courseStates', 'categoriesWithSubcategories'));
    }

    // Método para mostrar la view de crear curso
    public function showCreateCourse()
    {
        return view('pages.teacher.createCourse', compact('categoriesWithSubcategories'));
    }

    // Método para mostrar la vista de estadísticas del curso
    public function showCourseStats($id)
    {
        // Verificamos si el curso existe y si el usuario es el propietario
        $course = auth()->user()->coursesIsOwner()
            ->where('id', $id)
            ->with('subcategory:id,name')
            ->with('subcategory.category:id,name')
            ->with('owner:id,name,surname')
            ->first();

        // TODO: Añadir página 404
        // if (!$course) {
        //     abort(404);
        // }

        // dd($course->toArray());

        // Recuperamos los estudiantes inscritos en el curso
        // En tu controlador:
        $students = UserCourse::with(['status'])
            ->where('course_id', $course->id)
            ->get();

        dd($students->toArray());

        // Obtener el ID del curso desde la solicitud
        return view('pages.teacher.courseStats', compact('course'));
    }

    // Método para mostrar la vista de edición del curso
    public function editCourseView($id)
    {

        // Recuperamos las categorías y subcategorías
        $categoriesWithSubcategories = CategoryController::getCategoriesWithSubcategories();

        // Verificamos si el curso existe y si el usuario es el propietario
        $course = auth()->user()->coursesIsOwner()
            ->where('id', $id)
            ->where('status', 'draft')
            ->with('subcategory:id,name')
            ->with('subcategory.category:id,name')
            ->with('owner:id,name,surname')
            ->first();

        if (!$course) {
            return redirect()->route('teacher.dashboard');
        }

        // Recuperamos los capítulos del curso
        $chapters = $course->chapters()
            ->get();
        // dd($chapters->toArray());

        // dd($course->toArray());

        return view('pages.teacher.editCourse', compact('course', 'categoriesWithSubcategories', 'chapters'));
    }
}