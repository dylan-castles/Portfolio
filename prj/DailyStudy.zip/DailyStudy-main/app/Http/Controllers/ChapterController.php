<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Chapter;
use App\Models\Course;
use Illuminate\Support\Facades\DB;


class ChapterController extends Controller
{
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            // Validación de los datos del request
            $validated = $request->validate([
                'course_id' => 'required|exists:courses,id',
            ]);

            // Calcular el número del capítulo
            $lastChapter = Chapter::where('course_id', $validated['course_id'])
                ->orderBy('chapter_number', 'desc')
                ->first();

            $chapterNumber = $lastChapter ? $lastChapter->chapter_number + 1 : 1; // Si no hay capítulos, el número del capítulo será 1


            // Crear un nuevo capítulo
            $chapter = Chapter::create([
                'course_id' => $validated['course_id'],
                'chapter_number' => $chapterNumber,
                'title' => 'Chapter ' . $chapterNumber, // Título por defecto
                'is_exam' => false // Por defecto, no es un examen
            ]);

            // Retornar una respuesta exitosa
            return response()->json([
                'message' => 'Capítulo creado exitosamente.',
                'chapter' => $chapter
            ], 201);

        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while processing your request' . $e->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Course $course, Chapter $chapter)
    {
        // Verificamos si el curso existe y si el usuario es el propietario
        $ownedCourse = auth()->user()->coursesIsOwner()
            ->where('id', $course->id)
            ->first();

        // Si el curso no existe o el usuario no es el propietario, redirigimos al dashboard del profesor
        if (!$ownedCourse) {
            return redirect()->route('teacher.dashboard');
        }

        // Verificamos que el capítulo pertenezca al curso
        if ($chapter->course_id !== $ownedCourse->id) {
            return redirect()->route('teacher.dashboard');
        }

        // Recuperamos el capítulo y sus ejercicios y opciones
        $chapter = $chapter->load(['exercises.options']);

        // dd($chapter->toArray());

        // Retornamos la vista de edición del capítulo con los datos del curso y el capítulo
        return view('pages.teacher.editChapter', [
            'course' => $ownedCourse,
            'chapter' => $chapter
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        try {
            // Validar los datos del request
            $validated = $request->validate([
                'id' => 'required|exists:chapters,id',
                'chapter_number' => 'required|integer|min:1',
                'title' => 'required|string|max:255',
                'description' => 'nullable|string|max:1000',
                'content' => 'nullable|string',
                'is_exam' => 'nullable|boolean',
            ]);

            // Buscar el capítulo por ID
            $chapter = Chapter::findOrFail($validated['id']);

            // Verificar que el usuario sea el propietario del capítulo
            if ($chapter->course->owner_id !== auth()->id()) {
                return response()->json(['error' => 'Unauthorized'], 403);
            }

            // Actualizar los campos del capítulo
            $chapter->update([
                'chapter_number' => $validated['chapter_number'],
                'title' => $validated['title'],
                'description' => $validated['description'] ?? null,
                'content' => $validated['content'] ?? null,
                'is_exam' => $validated['is_exam'] ?? false, // Por defecto, no es un examen
            ]);

            // Retornar una respuesta exitosa
            return response()->json([
                'success' => true,
                'message' => 'Capítulo actualizado exitosamente.',
                'chapter' => $chapter
            ], 200);


        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while processing your request: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        try {
            // Validar que se haya proporcionado un ID
            $validated = $request->validate([
                'id' => 'required|exists:chapters,id',
            ]);

            $id = $validated['id'];

            // Iniciar transacción para asegurar la integridad de los datos
            DB::beginTransaction();

            // Buscar el capítulo por ID
            $chapter = Chapter::findOrFail($id);

            // Iterar por cada ejercicio del capítulo para eliminar las opciones asociadas
            foreach ($chapter->exercises as $exercise) {
                // Eliminar los progresos del ejercicio
                $exercise->progresses()->delete();

                // Eliminar las opciones del ejercicio
                $exercise->options()->delete();

                // Eliminar el ejercicio
                $exercise->delete();
            }

            // Eliminar el capítulo
            $chapter->delete();

            // Confirmar la transacción
            DB::commit();

            // Retornar una respuesta exitosa
            return response()->json(['message' => 'Capítulo eliminado exitosamente.'], 200);

        } catch (\Exception $e) {
            // Revertir la transacción en caso de error
            DB::rollBack();
            // Retornar un mensaje de error
            return response()->json(['error' => 'An error occurred while processing your request: ' . $e->getMessage()], 500);
        }
    }
}
