<?php

namespace App\Http\Controllers;

use App\Models\Receipt;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Barryvdh\DomPDF\Facade\Pdf;

class ReceiptController extends Controller
{
    public function getPurchaseHistory()
    {
        $user = Auth::user();
    
        // Obtener los recibos asociados al usuario y formatear los datos
        $receipts = $user->userCourses()
            ->whereNotNull('receipt_id') // Filtrar solo los cursos con recibo
            ->with(['receipt:id,payment_method,created_at']) // Cargar los datos del recibo
            ->select('receipt_id', 'price_paid') // Seleccionar campos específicos
            ->get()
            ->groupBy('receipt_id') // Agrupar por ID de recibo
            ->map(function ($group) {
                $firstItem = $group->first();
    
                // Validar que el recibo exista
                if (!$firstItem || !$firstItem->receipt) {
                    return null; // O manejar el caso de datos faltantes.
                }
    
                $receipt = $firstItem->receipt;
                return [
                    'receipt_id' => $firstItem->receipt_id,
                    'created_at' => $receipt->created_at,
                    'payment_method' => $receipt->payment_method,
                    'total_price' => $group->sum('price_paid'),
                ];
            })
            ->filter() // Eliminar cualquier dato nulo
            ->values(); // Reindexar los datos
    
        // Traer el último recibo asociado a las suscripciones
        $lastSubscriptionReceipt = $user->subscriptions()
            ->whereNotNull('receipt_id') // Filtrar solo las suscripciones con recibo
            ->with([
                'receipt:id,payment_method,created_at',
                'subscriptionProduct:id,name']) // Cargar los datos del recibo
            ->select('receipt_id', 'subscription_product_id', 'price_paid') // Seleccionar campos específicos
            ->latest('receipt_id') // Ordenar por el ID del recibo
            ->first(); // Obtener el último recibo asociado a las suscripciones

        // dd($receipts->toArray(), $lastSubscriptionReceipt->toArray());
    
        // Retornar la vista con los datos formateados
        return view('pages.student.myPurchases', compact('receipts', 'lastSubscriptionReceipt'));
    }

    public function download($id)
    {
        $receipt = Receipt::with('userCourses.course')->findOrFail($id);
        $user = Auth::user();
        $pdf = Pdf::loadView('pages.receipts.download', compact('receipt','user'));
        return $pdf->download('receipt_'.$receipt->id.'.pdf');
    }

    public function show($id)
    {
        $receipt = Receipt::with('userCourses.course')->findOrFail($id);

        return view('pages.receipts.show', compact('receipt'));
    }
}
