<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Course;
use App\Models\Note;
use App\Models\Progress;
use App\Models\Receipt;
use App\Models\Role;
use App\Models\Subscription;
use App\Models\SubscriptionProduct;
use App\Models\UserCertificate;
use App\Models\UserCourse;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class NoteController extends Controller {

    public function getMyNotes()
    {
        $user = Auth::user();
        $notes = $user->notes; // Asumiendo que tienes una relación notes en tu modelo User
        return view('pages.student.myNotes', compact('notes'));
    }

    public function show($id) {
        $note = Note::findOrFail($id);
        return view('pages.student.note', compact('note'));
    }

    public function update($id) {

        $request = Request();
        $note = Note::findOrFail($id);

        // Validar datos
        $request->validate([
            'title' => 'required|string|max:255',
            'content',
        ]);



        // Actualizar la nota
        $note->update([
            'title' => $request->input('title'),
            'content' => $request->input('content'),
        ]);

        // Si la petición espera JSON (AJAX)
        if($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'note' => $note,
                'message' => 'Nota actualizada correctamente'
            ]);
        }

        // Si es una petición normal, redirigir
        return redirect()->route('note.show', ['id' => $note->id])
            ->with('success', 'Nota actualizada correctamente.');
    }

    public function destroy($id) {
        $note = Note::findOrFail($id);
        $note->delete();

        return redirect()->back();
    }

    public function createAndRedirect() {
        $note = new Note();
        $user = Auth::user();
        $note->title = 'Nueva nota';
        $note->content = '';
        $note->owner_id = $user->id;
        $note->save();

        $request = request();

        if ($request->expectsJson()) {
            // Respuesta para petición AJAX
            return response()->json([
                'success' => true,
                'note' => $note,
                'message' => 'Nota creada correctamente'
            ]);
        }

        return redirect()->route('note.show', ['id' => $note->id]);
    }

    public function show2()
    {
        $user = Auth::user();
        $notes = $user->notes;
        return view('pages.student.myNotes2', compact('notes'));
    }

    public function getNoteContent($id)
    {
        $note = Note::findOrFail($id);
        return view('pages.student.note_content', compact('note'));
    }

}



?>
