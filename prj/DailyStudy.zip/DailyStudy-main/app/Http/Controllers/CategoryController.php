<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{

    // Método estático que devuelve categorias y subcategorías
    public static function getCategoriesWithSubcategories()
    {
        try {
            // Obtener categorías y subcategorías de la base de datos
            $categoriesWithSubcategories = Category::with('subcategories:id,name,category_id')
                ->select('id', 'name')
                ->get();

            return $categoriesWithSubcategories;
        } catch (\Exception $e) {
            return null;
        }
    }
}
