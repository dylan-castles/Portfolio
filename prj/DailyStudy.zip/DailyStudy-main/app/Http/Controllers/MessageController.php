<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;
use App\Models\Forum;
use App\Models\UserCourse;
use App\Events\ForumMessageSent;
use App\Services\PusherService;

class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            // Validar los datos de entrada
            $validated = $request->validate([
                'forum_id' => 'required|integer|exists:forums,id',
            ]);

            // find the forum ID from the validated data
            $forum = Forum::findOrFail($validated['forum_id']);

            // Verificar si el foro existe
            if (!$forum) {
                return response()->json(['error' => 'Forum not found.'], 404);
            }

            // Obtener el ID del usuario autenticado
            $userId = auth()->user();

            // Verificar si el usuario tiene acceso al foro
            if (!$this->hasAccessToForum($forum->id, $userId->id)) {
                return response()->json(['error' => 'You do not have access to this forum.'], 403);
            }

            // Obtener los mensajes del foro ordenados de más reciente a más antiguo
            $messages = $forum->messages()
                ->with([
                    'user' => function ($query) {
                        $query->select('id', 'name', 'surname', 'username', 'email', 'role_id')
                              ->with(['role' => function ($roleQuery) {
                                  $roleQuery->select('id', 'name');
                              }]);
                    }
                ])
                ->orderBy('created_at', 'asc')
                ->get();

            // Retornar los mensajes en formato JSON
            return response()->json($messages, 200);

        } catch (\Exception $e) {
            // Handle the exception, log it, or return an error response
            return response()->json(['error' => 'An error occurred while fetching messages.' . $e->getMessage()], 500);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            // Validar los datos de entrada
            $validated = $request->validate([
                'forum_id' => 'required|integer|exists:forums,id',
                'content' => 'required|string|max:255',
            ]);

            // Obtener el ID del usuario autenticado
            $userId = auth()->user()->id;

            // Verificar si el usuario tiene acceso al foro
            if (!$this->hasAccessToForum($validated['forum_id'], $userId)) {
                return response()->json(['error' => 'You do not have access to this forum.'], 403);
            }

            // Crear un nuevo mensaje
            $message = Message::create([
                'user_id' => $userId,
                'content' => $validated['content'],
                'forum_id' => $validated['forum_id'],
            ]);

            // Cargar relaciones igual que en index()
            $message->load([
                'user' => function ($query) {
                    $query->select('id', 'name', 'surname', 'username', 'email', 'role_id')
                          ->with(['role' => function ($roleQuery) {
                              $roleQuery->select('id', 'name');
                          }]);
                }
            ]);

            // Emitir evento a Pusher usando el servicio (API directa)
            $this->sendPusherForumMessage($message);

            // Retornar el mensaje creado en formato JSON
            return response()->json($message, 201);

        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while storing the message: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    /**
     * Comprueba si el usuario tiene acceso al foro (es decir, al curso del foro).
     * Devuelve true si el usuario tiene el curso y su estado NO es "Cart" (por ejemplo, status_id != 1).
     * Devuelve false si el usuario solo lo tiene en el carrito.
     */
    private function hasAccessToForum($forum_id, $user_id)
    {
        $forum = Forum::find($forum_id);
        
        if (!$forum) {
            return false;
        }

        // Verifica si el usuario es el propietario del foro
        if ($forum->course->owner_id == $user_id) {
            return true; // El propietario siempre tiene acceso
        }

        // Buscar el registro en user_courses para este usuario y el curso del foro
        $userCourse = UserCourse::where('user_id', $user_id)
            ->where('course_id', $forum->course_id)
            ->first();

        // Si no existe relación, no tiene acceso
        if (!$userCourse) {
            return false;
        }

        // Si el estado es "Cart" (por ejemplo, status_id == 1), no tiene acceso
        // Cambia el valor 1 si tu status_id para "Cart" es diferente
        if ($userCourse->status_id == 1) {
            return false;
        }

        // En cualquier otro caso, tiene acceso
        return true;
    }

    /**
     * Envía el mensaje a Pusher usando la API directa.
     */
    private function sendPusherForumMessage($message)
    {
        $pusher = new PusherService();
        $pusher->trigger(
            'forum.' . $message->forum_id,
            'new-message',
            [
                'message' => $message
            ]
        );
    }
}
