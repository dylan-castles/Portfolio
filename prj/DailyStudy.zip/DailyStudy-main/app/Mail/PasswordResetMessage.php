<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class PasswordResetMessage extends Mailable
{
    use Queueable, SerializesModels;

    public $userEmail;
    public $userName;
    public $token;

    public function __construct($userEmail, $userName, $token) {

        $this->userEmail = $userEmail;
        $this->userName = $userName;
        $this->token = $token;

    }

    public function build() {

        return $this->from($this->userEmail, $this->userName)->subject('DailyStudy')->view('pages.common.email.reset')
        ->with([
            'userEmail' => $this->userEmail,
            'userName' => $this->userName,
            'token' => $this->token,
        ]);

    }
}
