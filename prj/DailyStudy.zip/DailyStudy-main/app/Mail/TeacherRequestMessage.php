<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TeacherRequestMessage extends Mailable
{
    use Queueable, SerializesModels;

    public $userEmail;
    public $userName;
    public $linkedin;
    public $cvPath;
    public $portfolioPath;

    /**
     * Create a new message instance.
     *
     * @param object $user Usuario autenticado con propiedades necesarias
     */
    public function __construct($user)
    {
        $this->userEmail = $user->email;
        $this->userName = $user->name . ' ' . $user->surname;
        $this->linkedin = $user->linkedin ?? null;
        $this->cvPath = $user->cv;
        $this->portfolioPath = $user->portfolio;
    }

    /**
     * Build the message.
     */
    public function build()
    {
        $email = $this->from($this->userEmail, $this->userName)
        ->subject('New Teacher Request - DailyStudy')
        ->view('pages.common.email.request')
        ->with([
            'userEmail' => $this->userEmail,
            'userName' => $this->userName,
            'cvPath' => $this->cvPath,
            'portfolioPath' => $this->portfolioPath,
            'linkedin' => $this->linkedin, // opcional
        ]);


        // Adjuntar el currículum si existe
        if ($this->cvPath && file_exists(storage_path('app/' . $this->cvPath))) {
            $email->attach(storage_path('app/' . $this->cvPath), [
                'as' => 'CV_' . $this->userName . '.pdf',
                'mime' => 'application/pdf',
            ]);
        }

        // Adjuntar el portfolio si existe
        if ($this->portfolioPath && file_exists(storage_path('app/' . $this->portfolioPath))) {
            $email->attach(storage_path('app/' . $this->portfolioPath), [
                'as' => 'Portfolio_' . $this->userName . '.pdf',
                'mime' => 'application/pdf',
            ]);
        }

        return $email;
    }
}
