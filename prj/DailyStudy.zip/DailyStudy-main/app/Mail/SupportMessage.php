<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class SupportMessage extends Mailable
{
    use Queueable, SerializesModels;

    public $userEmail;
    public $userName;
    public $messageContent;

    public function __construct($userEmail, $userName, $messageContent) {

        $this->userEmail = $userEmail;
        $this->userName = $userName;
        $this->messageContent = $messageContent;

    }

    public function build() {

        return $this->from($this->userEmail, $this->userName, $this->messageContent)->subject('Mensaje de soporte desde DailyStudy')->view('pages.common.email.plainSupport')
        ->with([
            'userEmail' => $this->userEmail,
            'userName' => $this->userName,
            'messageContent' => $this->messageContent,
        ]);
        
    }

}