<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class RejectMessage extends Mailable
{
    use Queueable, SerializesModels;

    public $userEmail;
    public $userName;
    public $messageContent;
    public $courseTitle;

    public function __construct($userEmail, $userName, $messageContent, $courseTitle) {

        $this->userEmail = $userEmail;
        $this->userName = $userName;
        $this->messageContent = $messageContent;
        $this->courseTitle = $courseTitle;

    }

    public function build() {

        return $this->from($this->userEmail, $this->userName, $this->messageContent)->subject('DailyStudy')->text('pages.common.email.reject')
        ->with([
            'userEmail' => $this->userEmail,
            'userName' => $this->userName,
            'messageContent' => $this->messageContent,
        ]);

    }
}
