# DailyStudy

<p align="center">
  <img src="public/img/dailyStudyPortada.png" alt="Logo Daily Study" width="200px">
</p>

## Tabla de Contenidos

- [¿Qué es DailyStudy?](#qué-es-dailystudy)
- [Propósito y visión](#propósito-y-visión)
- [Resumen funcional](#resumen-funcional)
- [Arquitectura y módulos principales](#arquitectura-y-módulos-principales)
  - [Gestión de usuarios y roles](#gestión-de-usuarios-y-roles)
  - [Estructura de cursos, capítulos y progreso](#estructura-de-cursos-capítulos-y-progreso)
  - [Exámenes, certificados y gamificación](#exámenes-certificados-y-gamificación)
  - [Suscripciones y monetización](#suscripciones-y-monetización)
  - [Foros y comunidad](#foros-y-comunidad)
  - [Asistente de IA (AI Assistant)](#asistente-de-ia-ai-assistant)
- [Catálogo de cursos y categorías](#catálogo-de-cursos-y-categorías)
- [Tecnologías y dependencias](#tecnologías-y-dependencias)
- [Despliegue e instalación](#despliegue-e-instalación)
- [Equipo y contribuidores](#equipo-y-contribuidores)

---

## ¿Qué es DailyStudy?

**DailyStudy** es una plataforma web integral de aprendizaje y gestión de cursos en línea, con orientación tanto a usuarios individuales (estudiantes, autodidactas, docentes) como a empresas. Su objetivo es ofrecer una experiencia educativa moderna, flexible, gamificada y social, con certificados instantáneos y funcionalidades adaptadas a la profesionalización.

---

## Propósito y visión

> “Queremos acompañar a quienes dan sus primeros pasos en un sector, así como a quienes buscan profesionalizarse o reciclar sus conocimientos. Centralizamos la oferta formativa en un solo lugar, con certificaciones que validan el crecimiento profesional.”

La plataforma aspira a ser un puente entre talento y oportunidad, conectando aprendizaje, validación y comunidad.

---

## Resumen funcional

- Cursos gratuitos, de pago y premium, con múltiples categorías y subcategorías.
- Certificados descargables y automáticos.
- Gestión de usuarios y roles: estudiantes, profesores, revisores, administradores y empresas.
- Sistema de progreso detallado, notas personales, monedas y favoritos.
- Creación y edición de cursos (por profesores y empresas), con capítulos, exámenes y estadísticas.
- Suscripciones (Free, Premium, Company) y gestión de pagos con Stripe.
- Foros y mensajería para fomentar la comunidad y el soporte.
- Asistente de IA para consultas y ayuda contextual dentro de los cursos.
- Panel de administración avanzado para gestión de usuarios, roles, cursos y suscripciones.

---

## Arquitectura y módulos principales

### Gestión de usuarios y roles

- **Modelo User**: almacena información personal, credenciales, progreso, monedas, estado y rol.
- **Roles** (admin, teacher, student, revisor, company): Definidos en la base de datos y gestionados desde el panel de administración.
- **Autenticación**: Login por email/contraseña, Google OAuth2 y gestión avanzada de sesiones/recuperación de contraseña.
- **Suscripciones**: Relación entre usuarios y productos de suscripción (Free, Premium, Company).

### Estructura de cursos, capítulos y progreso

- **Modelo Course**: Cada curso contiene metadatos (título, descripción, tipo, precio, propietario, subcategoría, estado).
- **Capítulos**: Cada curso tiene capítulos ordenados, que pueden incluir contenido, ejercicios y exámenes.
- **Progreso**: 
  - Registro detallado por usuario, curso, capítulo y ejercicio.
  - Estados: Cart, Owned, In Progress, Completed, Redoing (ver migración y modelo `user_course_statuses`).
  - Los métodos en `CourseController` y `ProgressController` gestionan el avance, reinicio, finalización y seguimiento granular.
- **Gamificación**: Monedas obtenidas por completar cursos y logros visibles en el perfil.

### Exámenes, certificados y gamificación

- **Exámenes**: Capítulos pueden tener ejercicios tipo test, con validación automática.
- **Certificados**: Al completar cursos, el usuario puede descargar certificados personalizados (integración con PDF).
- **Sistema de favoritos**: Los usuarios pueden marcar cursos como favoritos, y el número de favoritos es visible en la ficha de cada curso.
- **Notas personales**: Sistema de notas asociado a cada usuario y curso, accesible desde el panel personal.

### Suscripciones y monetización

- **Productos de suscripción**: 
  - Free (acceso básico y sin caducidad)
  - Premium (todo incluido, duración limitada, pago individual)
  - Company (multiusuario, analíticas, admin tools)
- **Pagos**: Integración con Stripe para productos premium y empresa.
- **Carrito y compra de cursos individuales**.

### Foros y comunidad

- **Foros de curso**: Espacios de discusión y mensajería para cada curso, con eventos en tiempo real vía Pusher.
- **Mensajería interna**: Modelo `Message` y controlador específico para interacción en foros.
- **Soporte y FAQ**: Sección dedicada para soporte y preguntas frecuentes, gestionada vía panel de administración.

### Asistente de IA (AI Assistant)

- **Controlador `AIController`**: Permite a los estudiantes realizar preguntas contextuales sobre el contenido del curso y capítulo actual, recibiendo respuestas generadas por IA (modelo Ollama/Llama3).
- **TTS**: Conversión de texto a voz vía ElevenLabs API, para accesibilidad y ayuda auditiva.
- **Validación automática de acceso**: Solo usuarios con progreso en el curso pueden acceder al asistente para ese contenido.

---

## Catálogo de cursos y categorías

La plataforma cubre un amplio espectro de áreas (consultar seeds y vistas):

- **Tecnología**: Ciberseguridad, redes, desarrollo web, ciencia de datos, programación, sistemas operativos, bases de datos, etc.
- **Negocios**: Emprendimiento, marketing, management, finanzas, startups.
- **Artes**: Diseño gráfico, fotografía, edición de vídeo, producción musical.
- **Salud y bienestar**: Nutrición, fitness, yoga, salud mental.
- **Idiomas**: Inglés, español, francés, alemán.
- **Crecimiento personal**: Liderazgo, productividad, mindfulness, gestión del tiempo.

Ejemplo de cursos seed:
- "Mathematics for Engineers"
- "Complete PHP Course"
- "Introduction to Python"
- "Technical Drawing with AutoCAD"
- "Applied Lean Startup"
- "Yoga for Beginners"
- ...y muchos más, con capítulos y ejercicios detallados.

---

## Tecnologías y dependencias

- **Backend**: [Laravel 12.x](https://laravel.com/)
  - Eloquent ORM, migraciones, seeders, factories
  - Faker, Factories y Seeders para testing
- **Frontend**: Blade, Bootstrap 5, JavaScript modular
  - CKEditor, SweetAlert, Notyf para notificaciones e interacción
- **Integraciones**:
  - Stripe (pagos)
  - Pusher (websockets y eventos en tiempo real)
  - PHPMailer
  - ElevenLabs (TTS)
  - Google OAuth (login social)
- **DevOps y despliegue**:
  - Variables de entorno y migraciones automáticas
  - Configuración avanzada de logging y seguridad

---

## Despliegue e instalación

1. **Clona el repositorio**
   ```bash
   git clone https://github.com/Marcolo24/DailyStudy.git
   cd DailyStudy
   ```
2. **Instala dependencias**
   ```bash
   composer install
   ```
3. **Configura el entorno**
   ```bash
   cp .env.example .env
   # Edita .env para tus claves de BD, Stripe, Pusher, ElevenLabs, etc.
   ```
4. **Migraciones y seeders**
   ```bash
   php artisan key:generate
   php artisan migrate --seed
   ```
5. **Arranca el servidor**
   ```bash
   php artisan serve
   # o usa Laravel Sail para Docker
   ```
6. **Accede desde el navegador**
   ```
   http://localhost:8000
   ```

---

## Equipo y contribuidores

Proyecto desarrollado por la startup:

- **Manav Kumar Sharma**
- **Dylan Castles Cazalla**
- **Pol Marc Montero Toro**
- **Marc Colome Cuenca**

---

¿Quieres ver más detalles del código? Explora el repositorio:
[Ver código fuente en GitHub](https://github.com/Marcolo24/DailyStudy)

---

<p align="center">
  <b>Únete a la comunidad DailyStudy y forma parte de la revolución en educación digital.</b>
</p>
